# Google sign-in setup (one time)

Mask v2 signs users in with Google only. Account and data are tied to the Google account.

## 1. Google Cloud (console.cloud.google.com)
1. Create or select a project.
2. APIs & Services → OAuth consent screen: set it up (External, app name "Mask").
3. Create credentials → OAuth client ID:
   - **Web application**: this is the client ID you need. Also copy its client secret.
   - **Android**: package name `com.example.mask` (change it before store release), and the SHA-1 of your signing key. For EAS builds, get it with `npx eas-cli credentials` (Android → Keystore → SHA-1 fingerprint).

## 2. Supabase dashboard
Authentication → Providers → Google → enable. Paste the **Web** client ID and client secret. Save.

## 3. Your .env and eas.json
Set `EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID` to the **Web** client ID (the same value in `.env` and in `eas.json` for each build profile).

## 4. Build
`npx eas-cli build --platform android --profile preview`
