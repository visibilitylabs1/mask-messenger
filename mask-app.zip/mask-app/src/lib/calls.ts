// One-to-one WebRTC calls. Signaling runs over private Supabase Realtime channels,
// so only members of the conversation can take part. Needs a development build
// (react-native-webrtc does not run in Expo Go).
import {
  mediaDevices,
  RTCPeerConnection,
  RTCSessionDescription,
  RTCIceCandidate,
  type MediaStream,
} from 'react-native-webrtc';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { PermissionsAndroid, Platform } from 'react-native';
import InCallManager from 'react-native-incall-manager';
import { supabase } from './supabase';

export type CallKind = 'audio' | 'video';
export type CallStatus = 'ringing' | 'connecting' | 'connected' | 'ended' | 'failed' | 'rejected' | 'missed';

const CONNECT_TIMEOUT_MS = 45_000;

function fmtDuration(ms: number) {
  const total = Math.floor(ms / 1000);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
const DISCONNECT_GRACE_MS = 10_000;


// TURN credentials come from the server, minted per request. Falls back to STUN if TURN is not set up.
async function getIceServers(): Promise<any[]> {
  try {
    const { data, error } = await supabase.functions.invoke('turn-credentials');
    if (!error && Array.isArray(data?.iceServers) && data.iceServers.length > 0) return data.iceServers;
  } catch {}
  return [{ urls: 'stun:stun.cloudflare.com:3478' }, { urls: 'stun:stun.l.google.com:19302' }];
}

const RING_TIMEOUT_MS = 40_000;

export type CallEvents = {
  onStatus: (status: CallStatus, note?: string) => void;
  onLocalStream: (stream: MediaStream) => void;
  onRemoteStream: (stream: MediaStream) => void;
};

export type CallOptions = {
  conversationId: string;
  meId: string;
  meName: string;
  peerId: string;
  kind: CallKind;
  events: CallEvents;
  logId?: string;
};

export type CallController = {
  start: () => Promise<void>; // caller
  accept: () => Promise<void>; // callee
  hangup: () => void;
  toggleMute: () => boolean;
  toggleVideo: () => boolean;
  switchCamera: () => void;
  setSpeaker: (on: boolean) => void;
  logId: () => string | null;
};

// Android needs runtime permission before the camera or mic can be opened.
async function ensurePermissions(kind: CallKind) {
  if (Platform.OS !== 'android') return;
  const wanted: any[] = [PermissionsAndroid.PERMISSIONS.RECORD_AUDIO];
  if (kind === 'video') wanted.push(PermissionsAndroid.PERMISSIONS.CAMERA);
  const res = await PermissionsAndroid.requestMultiple(wanted);
  const denied = wanted.some((p) => res[p] !== PermissionsAndroid.RESULTS.GRANTED);
  if (denied) throw new Error(kind === 'video' ? 'Allow camera and microphone access to make video calls.' : 'Allow microphone access to make calls.');
}

export function createCall(o: CallOptions): CallController {
  let pc: RTCPeerConnection | null = null;
  let local: MediaStream | null = null;
  let convCh: RealtimeChannel | null = null;
  let userCh: RealtimeChannel | null = null;
  let ringTimer: ReturnType<typeof setTimeout> | null = null;
  let finished = false;
  let remoteDescSet = false;
  let offered = false;
  let connectedAt: number | null = null;
  let logId: string | null = o.logId ?? null;
  let answered = false;
  let connectTimer: ReturnType<typeof setTimeout> | null = null;
  let disconnectTimer: ReturnType<typeof setTimeout> | null = null;

  const clearConnectTimers = () => {
    if (connectTimer) clearTimeout(connectTimer);
    if (disconnectTimer) clearTimeout(disconnectTimer);
    connectTimer = null;
    disconnectTimer = null;
  };
  // Fails the call if it does not connect in time (for example, a network that blocks direct paths and has no TURN).
  const startConnectTimer = () => {
    if (connectTimer) return;
    connectTimer = setTimeout(() => finish('failed', 'Could not connect. Check your network and try again.'), CONNECT_TIMEOUT_MS);
  };
  const pendingIce: any[] = [];

  const sendConv = (event: string, payload: Record<string, unknown>) =>
    convCh?.send({ type: 'broadcast', event, payload });

  const clearRing = () => {
    if (ringTimer) clearTimeout(ringTimer);
    ringTimer = null;
  };

  const finish = (status: CallStatus, note?: string) => {
    if (finished) return;
    finished = true;
    clearRing();
    clearConnectTimers();
    try { pc?.close(); } catch {}
    pc = null;
    local?.getTracks().forEach((t) => t.stop());
    local = null;
    if (convCh) supabase.removeChannel(convCh);
    if (userCh) supabase.removeChannel(userCh);
    convCh = null;
    userCh = null;
    // Record the outcome. A call that never connected is 'missed' when the caller gives up.
    if (logId) {
      const dbStatus = connectedAt !== null ? 'ended' : status === 'ended' ? 'missed' : status;
      const seconds = connectedAt !== null ? Math.round((Date.now() - connectedAt) / 1000) : 0;
      supabase.from('call_logs')
        .update({ status: dbStatus, duration_seconds: seconds, ended_at: new Date().toISOString() })
        .eq('id', logId)
        .then(() => {}, () => {});
    }
    try { InCallManager.stop(); } catch {}
    const talked = connectedAt !== null && status === 'ended' ? `Ended · ${fmtDuration(Date.now() - connectedAt)}` : note;
    o.events.onStatus(status, talked);
  };

  const openMedia = async () => {
    try { InCallManager.start({ media: o.kind === 'video' ? 'video' : 'audio' }); } catch {}
    local = await mediaDevices.getUserMedia({
      audio: true,
      video: o.kind === 'video' ? { facingMode: 'user' } : false,
    }) as unknown as MediaStream;
    o.events.onLocalStream(local);
  };

  const makePeer = async () => {
    pc = new RTCPeerConnection({ iceServers: await getIceServers() });
    (local as any)?.getTracks().forEach((t: any) => pc!.addTrack(t, local as any));
    (pc as any).onicecandidate = (e: any) => {
      if (e.candidate) sendConv('call-ice', { candidate: e.candidate });
    };
    (pc as any).ontrack = (e: any) => {
      if (e.streams?.[0]) o.events.onRemoteStream(e.streams[0]);
    };
    (pc as any).onconnectionstatechange = () => {
      const s = (pc as any)?.connectionState;
      if (s === 'connected') {
        clearConnectTimers();
        if (connectedAt === null) connectedAt = Date.now();
        if (logId) supabase.from('call_logs').update({ status: 'answered' }).eq('id', logId).then(() => {}, () => {});
        o.events.onStatus('connected');
      } else if (s === 'disconnected') {
        // Often recovers on its own (Wi-Fi to mobile data switch). Only fail if it stays down.
        if (!disconnectTimer) disconnectTimer = setTimeout(() => finish('failed', 'Connection lost'), DISCONNECT_GRACE_MS);
      } else if (s === 'failed') {
        finish('failed', 'Connection lost');
      }
    };
  };

  const joinConversation = () =>
    new Promise<void>((resolve, reject) => {
      convCh = supabase.channel(`conv:${o.conversationId}:call`, {
        config: { private: true, broadcast: { self: false } },
      });
      convCh
        .on('broadcast', { event: 'call-accept' }, () => onAccepted())
        .on('broadcast', { event: 'call-offer' }, ({ payload }) => onOffer(payload.sdp))
        .on('broadcast', { event: 'call-answer' }, ({ payload }) => onAnswer(payload.sdp))
        .on('broadcast', { event: 'call-ice' }, ({ payload }) => onIce(payload.candidate))
        .on('broadcast', { event: 'call-hangup' }, () => finish('ended'))
        .on('broadcast', { event: 'call-decline' }, () => finish('rejected', 'Call declined'))
        .subscribe((status, err) => {
          if (status === 'SUBSCRIBED') resolve();
          if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') reject(err ?? new Error(status));
        });
    });

  const flushIce = async () => {
    remoteDescSet = true;
    while (pendingIce.length) await pc?.addIceCandidate(new RTCIceCandidate(pendingIce.shift()));
  };

  // Caller: the callee accepted, so create and send the offer.
  const onAccepted = async () => {
    if (!pc || offered) return;
    offered = true;
    startConnectTimer();
    clearRing();
    o.events.onStatus('connecting');
    const offer = await pc.createOffer({});
    await pc.setLocalDescription(offer);
    sendConv('call-offer', { sdp: pc.localDescription });
  };

  const onOffer = async (sdp: any) => {
    if (!pc || answered) return;
    answered = true;
    await pc.setRemoteDescription(new RTCSessionDescription(sdp));
    await flushIce();
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    sendConv('call-answer', { sdp: pc.localDescription });
  };

  const onAnswer = async (sdp: any) => {
    if (!pc) return;
    await pc.setRemoteDescription(new RTCSessionDescription(sdp));
    await flushIce();
  };

  const onIce = async (candidate: any) => {
    if (!pc) return;
    if (!remoteDescSet) pendingIce.push(candidate);
    else await pc.addIceCandidate(new RTCIceCandidate(candidate));
  };

  return {
    async start() {
      o.events.onStatus('ringing');
      await ensurePermissions(o.kind);
      await openMedia();
      await joinConversation();
      await makePeer();
      userCh = supabase.channel(`user:${o.peerId}`, { config: { private: true } });
      await new Promise<void>((resolve, reject) =>
        userCh!.subscribe((s, err) => (s === 'SUBSCRIBED' ? resolve() : s === 'CHANNEL_ERROR' ? reject(err) : null)),
      );
      // The call row comes first. The database sends the callee's ring push from this insert.
      const { data: row } = await supabase
        .from('call_logs')
        .insert({ conversation_id: o.conversationId, caller_id: o.meId, callee_id: o.peerId, kind: o.kind })
        .select('id')
        .single();
      logId = row?.id ?? null;
      const sent = await userCh.send({
        type: 'broadcast',
        event: 'call-invite',
        payload: { conversationId: o.conversationId, kind: o.kind, fromId: o.meId, fromName: o.meName, logId },
      });
      if (sent !== 'ok') {
        finish('failed', 'Could not reach the other person. Check your connection.');
        return;
      }
      ringTimer = setTimeout(() => {
        sendConv('call-hangup', {});
        finish('missed', 'No answer');
      }, RING_TIMEOUT_MS);
    },

    async accept() {
      o.events.onStatus('connecting');
      startConnectTimer();
      await ensurePermissions(o.kind);
      await openMedia();
      await joinConversation();
      await makePeer();
      // Tell the caller we are ready. The caller then sends the offer.
      sendConv('call-accept', {});
    },

    hangup() {
      sendConv('call-hangup', {});
      finish('ended');
    },

    toggleVideo() {
      const track = (local as any)?.getVideoTracks?.()[0];
      if (!track) return false;
      track.enabled = !track.enabled;
      return track.enabled;
    },
    switchCamera() {
      const track = (local as any)?.getVideoTracks?.()[0];
      try { track?._switchCamera?.(); } catch {}
    },
    setSpeaker(on: boolean) {
      try { InCallManager.setSpeakerphoneOn(on); } catch {}
    },
    logId() {
      return logId;
    },
    toggleMute() {
      const track = (local as any)?.getAudioTracks?.()[0];
      if (!track) return false;
      track.enabled = !track.enabled;
      return !track.enabled;
    },
  };
}

// Callee declines: tell the caller right away so their phone stops ringing.
export async function declineCall(conversationId: string, logId?: string | null): Promise<void> {
  const ch = supabase.channel(`conv:${conversationId}:call`, { config: { private: true, broadcast: { self: false } } });
  await new Promise<void>((resolve) =>
    ch.subscribe((status) => {
      if (status === 'SUBSCRIBED' || status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') resolve();
    }),
  );
  await ch.send({ type: 'broadcast', event: 'call-decline', payload: {} });
  if (logId) await supabase.from('call_logs').update({ status: 'rejected', ended_at: new Date().toISOString() }).eq('id', logId);
  supabase.removeChannel(ch);
}
