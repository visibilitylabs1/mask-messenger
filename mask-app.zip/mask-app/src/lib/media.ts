import * as FileSystem from 'expo-file-system';
import * as ImagePicker from 'expo-image-picker';
import * as ImageManipulator from 'expo-image-manipulator';
import { Audio } from 'expo-av';
import { decode } from 'base64-arraybuffer';
import { supabase } from './supabase';
import { newId } from './api';

const urlCache = new Map<string, { url: string; expiresAt: number }>();

export async function signedUrl(bucket: 'avatars' | 'chat-media', path: string): Promise<string> {
  const cacheKey = `${bucket}/${path}`;
  const hit = urlCache.get(cacheKey);
  if (hit && hit.expiresAt > Date.now() + 60_000) return hit.url;
  const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 3600);
  if (error || !data) throw error ?? new Error('Could not load media');
  urlCache.set(cacheKey, { url: data.signedUrl, expiresAt: Date.now() + 3600_000 });
  return data.signedUrl;
}

async function uploadBytes(bucket: 'avatars' | 'chat-media', path: string, uri: string, contentType: string) {
  const base64 = await FileSystem.readAsStringAsync(uri, { encoding: FileSystem.EncodingType.Base64 });
  const { error } = await supabase.storage.from(bucket).upload(path, decode(base64), { contentType, upsert: false });
  if (error) throw new Error(`Upload failed: ${error.message}`);
  return path;
}

// Any picked image (any size, any shape, PNG/HEIC/JPEG) becomes a JPEG whose longest side is at most maxSide.
export async function prepareImage(uri: string, width?: number, height?: number, maxSide = 1600): Promise<string> {
  const w = width ?? 0;
  const h = height ?? 0;
  const actions: ImageManipulator.Action[] = [];
  if (Math.max(w, h) > maxSide) actions.push({ resize: w >= h ? { width: maxSide } : { height: maxSide } });
  const out = await ImageManipulator.manipulateAsync(uri, actions, { compress: 0.8, format: ImageManipulator.SaveFormat.JPEG });
  return out.uri;
}

export async function uploadAvatar(userId: string, uri: string) {
  const jpg = await prepareImage(uri, 512, 512, 512);
  return uploadBytes('avatars', `${userId}/${newId()}.jpg`, jpg, 'image/jpeg');
}
export async function uploadChatImage(conversationId: string, uri: string) {
  return uploadBytes('chat-media', `${conversationId}/${newId()}.jpg`, uri, 'image/jpeg');
}
export async function uploadVoiceNote(conversationId: string, uri: string) {
  return uploadBytes('chat-media', `${conversationId}/${newId()}.m4a`, uri, 'audio/m4a');
}

export async function pickImage(): Promise<{ uri: string; width: number; height: number } | null> {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('Allow photo access in Settings to share images.');
  const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 1, allowsEditing: false });
  if (res.canceled) return null;
  const a = res.assets[0];
  return { uri: a.uri, width: a.width ?? 0, height: a.height ?? 0 };
}

export async function pickAvatar(): Promise<string | null> {
  const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!perm.granted) throw new Error('Allow photo access in Settings to choose a picture.');
  const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 1, allowsEditing: true, aspect: [1, 1] });
  return res.canceled ? null : res.assets[0].uri;
}

let activeRecording: Audio.Recording | null = null;

export async function startVoiceNote(): Promise<void> {
  const perm = await Audio.requestPermissionsAsync();
  if (!perm.granted) throw new Error('Allow microphone access to send voice notes.');
  await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
  const { recording } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
  activeRecording = recording;
}

// Read the status BEFORE unloading. After stopAndUnloadAsync the recording can no longer report its status.
export async function stopVoiceNote(): Promise<{ uri: string; durationMs: number } | null> {
  if (!activeRecording) return null;
  const rec = activeRecording;
  activeRecording = null;
  const status = await rec.getStatusAsync();
  await rec.stopAndUnloadAsync();
  await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
  const uri = rec.getURI();
  if (!uri) return null;
  return { uri, durationMs: status.durationMillis ?? 0 };
}

export async function cancelVoiceNote(): Promise<void> {
  if (!activeRecording) return;
  const rec = activeRecording;
  activeRecording = null;
  try { await rec.stopAndUnloadAsync(); } catch {}
  await Audio.setAudioModeAsync({ allowsRecordingIOS: false, playsInSilentModeIOS: true });
}
