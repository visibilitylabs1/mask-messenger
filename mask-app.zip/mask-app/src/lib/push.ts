import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { supabase } from './supabase';

// Show notifications even while the app is open, and play the sound.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

async function setupChannels() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync('messages', {
    name: 'Messages',
    importance: Notifications.AndroidImportance.HIGH,
    lightColor: '#FF7A1A',
  });
  await Notifications.setNotificationChannelAsync('calls', {
    name: 'Calls',
    importance: Notifications.AndroidImportance.MAX,
    vibrationPattern: [0, 500, 300, 500],
    lightColor: '#2F7BFF',
    sound: 'default',
  });
}

let myToken: string | null = null;

// Asks for permission, gets the Expo push token and stores it for this user.
// Buttons shown on call notifications: Accept opens the call, Decline rejects it without opening the app.
async function setupCategories() {
  await Notifications.setNotificationCategoryAsync('call', [
    { identifier: 'accept', buttonTitle: 'Accept', options: { opensAppToForeground: true } },
    { identifier: 'decline', buttonTitle: 'Decline', options: { opensAppToForeground: false } },
  ]);
}

export async function registerForPush(userId: string): Promise<void> {
  if (!Device.isDevice) return;
  await setupChannels();
  await setupCategories().catch(() => {});

  const existing = await Notifications.getPermissionsAsync();
  let status = existing.status;
  if (status !== 'granted') status = (await Notifications.requestPermissionsAsync()).status;
  if (status !== 'granted') return;

  const projectId = Constants.expoConfig?.extra?.eas?.projectId as string | undefined;
  const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
  myToken = token;
  await supabase.from('push_tokens').upsert(
    { user_id: userId, token, platform: Platform.OS === 'ios' ? 'ios' : 'android', updated_at: new Date().toISOString() },
    { onConflict: 'user_id,token' },
  );
}

// Removes this device's token on sign-out, so a logged-out phone never receives someone else's notifications.
export async function unregisterPush(userId: string): Promise<void> {
  if (!myToken) return;
  await supabase.from('push_tokens').delete().eq('user_id', userId).eq('token', myToken);
  myToken = null;
}

// Called when the user taps a notification. Also handles a tap that opened a closed app.
// Returns an unsubscribe function.
export function onNotificationTap(handler: (data: Record<string, string>, action: string) => void) {
  const sub = Notifications.addNotificationResponseReceivedListener((resp) => {
    handler((resp.notification.request.content.data ?? {}) as Record<string, string>, resp.actionIdentifier);
  });
  Notifications.getLastNotificationResponseAsync()
    .then((resp) => {
      if (!resp) return;
      handler((resp.notification.request.content.data ?? {}) as Record<string, string>, resp.actionIdentifier);
      Notifications.clearLastNotificationResponseAsync().catch(() => {});
    })
    .catch(() => {});
  return () => sub.remove();
}
