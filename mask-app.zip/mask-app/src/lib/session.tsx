import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { AppState } from 'react-native';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './supabase';
import { fetchMyProfile, type Profile } from './api';

export type IncomingCall = {
  conversationId: string;
  kind: 'audio' | 'video';
  fromId: string;
  fromName: string;
  logId?: string;
};

type SessionState = {
  session: Session | null;
  profile: Profile | null;
  ready: boolean;
  onlineIds: Set<string>;
  incomingCall: IncomingCall | null;
  refreshProfile: () => Promise<void>;
  dismissIncoming: () => void;
};

const Ctx = createContext<SessionState | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [ready, setReady] = useState(false);
  const [onlineIds, setOnlineIds] = useState<Set<string>>(new Set());
  const [incomingCall, setIncomingCall] = useState<IncomingCall | null>(null);

  const uid = session?.user.id;

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(async ({ data: { session: s } }) => {
      if (!mounted) return;
      setSession(s);
      if (s) setProfile(await fetchMyProfile(s.user.id).catch(() => null));
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange(async (_event, s) => {
      setSession(s);
      setProfile(s ? await fetchMyProfile(s.user.id).catch(() => null) : null);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  // Refresh tokens only while the app is open, and record when the user was last active.
  useEffect(() => {
    if (!uid) return;
    const touch = async () => {
      await supabase.from('profiles').update({ last_seen_at: new Date().toISOString() }).eq('id', uid);
    };
    touch();
    const sub = AppState.addEventListener('change', (state) => {
      if (state === 'active') {
        supabase.auth.startAutoRefresh();
        touch();
      } else {
        supabase.auth.stopAutoRefresh();
      }
    });
    return () => sub.remove();
  }, [uid]);

  // Presence: who is online right now. Only ids are shared, never profile details.
  useEffect(() => {
    if (!uid) return;
    const ch = supabase.channel('online', { config: { presence: { key: uid }, private: true } });
    ch.on('presence', { event: 'sync' }, () => {
      setOnlineIds(new Set(Object.keys(ch.presenceState())));
    }).subscribe(async (status) => {
      if (status === 'SUBSCRIBED') await ch.track({ online_at: new Date().toISOString() });
    });
    return () => {
      supabase.removeChannel(ch);
    };
  }, [uid]);

  // Incoming call ringing on this user's private topic.
  useEffect(() => {
    if (!uid) return;
    const ch = supabase.channel(`user:${uid}`, { config: { private: true } });
    ch.on('broadcast', { event: 'call-invite' }, ({ payload }) => {
      setIncomingCall(payload as IncomingCall);
    }).subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [uid]);

  const value = useMemo<SessionState>(
    () => ({
      session,
      profile,
      ready,
      onlineIds,
      incomingCall,
      refreshProfile: async () => {
        const { data: { session: s } } = await supabase.auth.getSession();
        setProfile(s ? await fetchMyProfile(s.user.id) : null);
      },
      dismissIncoming: () => setIncomingCall(null),
    }),
    [session, profile, ready, onlineIds, incomingCall],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSession(): SessionState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useSession must be used inside SessionProvider');
  return v;
}
