import { Audio } from 'expo-av';

// Ringtones are looped until stopped. One sound plays at a time.
let current: Audio.Sound | null = null;

async function play(asset: number) {
  await stopTone();
  await Audio.setAudioModeAsync({
    allowsRecordingIOS: false,
    playsInSilentModeIOS: true,
    staysActiveInBackground: false,
    shouldDuckAndroid: true,
  });
  const { sound } = await Audio.Sound.createAsync(asset, { isLooping: true, volume: 1 });
  current = sound;
  await sound.playAsync();
}

// Incoming call ring (callee side).
export function startRingtone() {
  return play(require('../../assets/ringtone.wav'));
}

// Outgoing ringback while the other person's phone rings (caller side).
export function startRingback() {
  return play(require('../../assets/ringback.wav'));
}

export async function stopTone() {
  const s = current;
  current = null;
  if (!s) return;
  try {
    await s.stopAsync();
    await s.unloadAsync();
  } catch {}
}
