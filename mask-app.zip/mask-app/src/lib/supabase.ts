import 'react-native-url-polyfill/auto';
import * as SecureStore from 'expo-secure-store';
import { createClient } from '@supabase/supabase-js';

const url = process.env.EXPO_PUBLIC_SUPABASE_URL;
const key = process.env.EXPO_PUBLIC_SUPABASE_KEY;
if (!url || !key) throw new Error('Set EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_KEY in .env');

// SecureStore caps each value at about 2 KB, and a Supabase session can be larger,
// so the session is stored across numbered chunks in the device keychain / keystore.
const CHUNK = 1800;

const secureStorage = {
  async getItem(name: string) {
    const count = await SecureStore.getItemAsync(`${name}.count`);
    if (count === null) return SecureStore.getItemAsync(name);
    let value = '';
    for (let i = 0; i < Number(count); i++) {
      value += (await SecureStore.getItemAsync(`${name}.${i}`)) ?? '';
    }
    return value;
  },
  async setItem(name: string, value: string) {
    const parts = Math.max(1, Math.ceil(value.length / CHUNK));
    for (let i = 0; i < parts; i++) {
      await SecureStore.setItemAsync(`${name}.${i}`, value.slice(i * CHUNK, (i + 1) * CHUNK));
    }
    await SecureStore.setItemAsync(`${name}.count`, String(parts));
  },
  async removeItem(name: string) {
    const count = await SecureStore.getItemAsync(`${name}.count`);
    if (count !== null) {
      for (let i = 0; i < Number(count); i++) await SecureStore.deleteItemAsync(`${name}.${i}`);
    }
    await SecureStore.deleteItemAsync(`${name}.count`);
    await SecureStore.deleteItemAsync(name);
  },
};

export const supabase = createClient(url, key, {
  auth: {
    storage: secureStorage,
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
});

export const SUPABASE_URL = url;
