import { GoogleSignin, isErrorWithCode, statusCodes } from '@react-native-google-signin/google-signin';
import { supabase } from './supabase';

// Web client ID from Google Cloud (used as audience for the ID token). Not secret.
const WEB_CLIENT_ID = process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID;

export function configureGoogle() {
  if (!WEB_CLIENT_ID) throw new Error('Set EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID in .env');
  GoogleSignin.configure({ webClientId: WEB_CLIENT_ID, scopes: ['profile', 'email'] });
}

// Returns false if the user closed the Google picker.
export async function signInWithGoogle(): Promise<boolean> {
  try {
    await GoogleSignin.hasPlayServices({ showPlayServicesUpdateDialog: true });
    const res = await GoogleSignin.signIn();
    if (res.type === 'cancelled') return false;
    const idToken = res.data.idToken;
    if (!idToken) throw new Error('Google did not return an ID token.');
    const { error } = await supabase.auth.signInWithIdToken({ provider: 'google', token: idToken });
    if (error) throw error;
    return true;
  } catch (e) {
    if (isErrorWithCode(e) && e.code === statusCodes.SIGN_IN_CANCELLED) return false;
    throw e;
  }
}

export async function signOutOfGoogle() {
  try {
    await GoogleSignin.signOut();
  } catch {}
}
