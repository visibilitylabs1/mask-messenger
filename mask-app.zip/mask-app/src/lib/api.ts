import { supabase } from './supabase';

export type Profile = {
  id: string;
  username: string;
  display_name: string;
  gender: string;
  age: number;
  avatar_path: string | null;
  bio: string | null;
  last_seen_at: string;
};

export type MessageKind = 'text' | 'image' | 'voice';
export type Reaction = { emoji: string; user_id: string };

export type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  client_id: string;
  kind: MessageKind;
  body: string | null;
  media_path: string | null;
  media_duration_ms: number | null;
  created_at: string;
  delivered_at: string | null;
  read_at: string | null;
  reply_to_id: string | null;
  forwarded: boolean;
  message_reactions: Reaction[];
};

export type ChatSummary = {
  conversationId: string;
  kind?: 'direct' | 'group';
  other: Pick<Profile, 'id' | 'username' | 'display_name' | 'avatar_path'>;
  lastAt: string;
  lastKind: MessageKind | null;
  lastBody: string | null;
  unread: number;
};

const USERNAME_RE = /^[a-z0-9_]{3,20}$/;

export function validateUsername(raw: string): string | null {
  if (!USERNAME_RE.test(raw.trim().toLowerCase())) return 'Use 3–20 letters, numbers or underscores.';
  return null;
}

// Message ids for dedupe. Not security-sensitive, so Math.random is fine here.
export function newId(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

async function functionErrorMessage(error: unknown, fallback: string): Promise<string> {
  try {
    const ctx = (error as { context?: Response }).context;
    const body = ctx ? await ctx.json() : null;
    return body?.error ?? fallback;
  } catch {
    return fallback;
  }
}

export async function fetchMyProfile(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase.from('profiles').select('*').eq('id', userId).maybeSingle();
  if (error) throw error;
  return (data as Profile) ?? null;
}

// ---------- Profile setup (after Google sign-in) ----------

export async function createProfile(input: {
  username: string;
  displayName: string;
  gender: string;
  age: number;
  bio?: string | null;
  avatarPath?: string | null;
}): Promise<Profile> {
  let { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    // Guest: no email or phone. An anonymous session is created when they finish onboarding.
    const { data, error } = await supabase.auth.signInAnonymously();
    if (error) throw error;
    user = data.user;
  }
  if (!user) throw new Error('Could not start a session. Please try again.');

  const { data, error } = await supabase
    .from('profiles')
    .insert({
      id: user.id,
      username: input.username.trim().toLowerCase(),
      display_name: input.displayName.trim(),
      gender: input.gender,
      age: input.age,
      avatar_path: input.avatarPath ?? null,
      bio: input.bio?.trim() || null,
    })
    .select('*')
    .single();

  if (error) {
    if (error.code === '23505') throw new Error('That username is taken. Try another.');
    throw new Error(error.message);
  }
  return data as Profile;
}

export async function updateProfile(userId: string, patch: { display_name?: string; avatar_path?: string | null }) {
  const { data, error } = await supabase.from('profiles').update(patch).eq('id', userId).select('*').single();
  if (error) throw error;
  return data as Profile;
}

// Deletes the account and all data tied to it. Irreversible.
export async function deleteAccount(): Promise<void> {
  const { error } = await supabase.functions.invoke('delete-account');
  if (error) throw new Error(await functionErrorMessage(error, 'Could not delete the account.'));
  await supabase.auth.signOut();
}

// ---------- Search ----------

export async function searchUsers(query: string, meId: string) {
  const q = query.trim().toLowerCase().replace(/[%_\\]/g, '\\$&');
  if (q.length < 2) return [];
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, display_name, avatar_path')
    .ilike('username', `${q}%`)
    .neq('id', meId)
    .limit(20);
  if (error) throw error;
  return data ?? [];
}

export async function startDirectChat(otherId: string): Promise<string> {
  const { data, error } = await supabase.rpc('get_or_create_direct_conversation', { other_user: otherId });
  if (error) throw error;
  return data as string;
}

// ---------- Chats ----------

export async function loadChats(meId: string): Promise<ChatSummary[]> {
  const { data: mine, error } = await supabase.from('conversation_members').select('conversation_id').eq('user_id', meId);
  if (error) throw error;
  const ids = (mine ?? []).map((r) => r.conversation_id as string);
  if (ids.length === 0) return [];

  const [{ data: convs, error: cErr }, { data: others, error: otherErr }] = await Promise.all([
    supabase.from('conversations').select('id, kind, title, avatar_path, last_message_at').in('id', ids),
    supabase.from('conversation_members').select('conversation_id, profiles(id, username, display_name, avatar_path)').in('conversation_id', ids).neq('user_id', meId),
  ]);
  if (cErr) throw cErr;
  if (otherErr) throw otherErr;

  // One other person per direct chat. Groups show the group's name and photo instead.
  const otherByConv: Record<string, ChatSummary['other']> = {};
  (others ?? []).forEach((row) => {
    const id = row.conversation_id as string;
    if (!otherByConv[id]) otherByConv[id] = row.profiles as unknown as ChatSummary['other'];
  });

  const summaries = await Promise.all(
    (convs ?? []).map(async (c) => {
      const convId = c.id as string;
      const isGroup = c.kind === 'group';
      const other: ChatSummary['other'] | undefined = isGroup
        ? { id: convId, username: '', display_name: (c.title as string) ?? 'Group', avatar_path: (c.avatar_path as string) ?? null }
        : otherByConv[convId];
      if (!other) return null;
      const [{ data: last }, { count }] = await Promise.all([
        supabase.from('messages').select('kind, body, created_at').eq('conversation_id', convId).order('created_at', { ascending: false }).limit(1).maybeSingle(),
        supabase.from('messages').select('id', { count: 'exact', head: true }).eq('conversation_id', convId).neq('sender_id', meId).is('read_at', null),
      ]);
      return {
        conversationId: convId,
        kind: isGroup ? 'group' : 'direct',
        other,
        lastAt: last?.created_at ?? '1970-01-01T00:00:00Z',
        lastKind: (last?.kind as MessageKind) ?? null,
        lastBody: last?.body ?? null,
        unread: count ?? 0,
      } satisfies ChatSummary;
    }),
  );

  return (summaries.filter(Boolean) as ChatSummary[]).sort((a, b) => (a.lastAt < b.lastAt ? 1 : -1));
}

export async function fetchMessages(convId: string, limit = 60): Promise<Message[]> {
  const { data, error } = await supabase
    .from('messages')
    .select('*, message_reactions(emoji, user_id)')
    .eq('conversation_id', convId)
    .order('created_at', { ascending: false })
    .limit(limit);
  if (error) throw error;
  return ((data ?? []) as unknown as Message[]).reverse();
}

export async function sendMessage(input: {
  clientId?: string;
  replyToId?: string | null;
  forwarded?: boolean;
  conversationId: string;
  senderId: string;
  kind: MessageKind;
  body?: string;
  mediaPath?: string;
  durationMs?: number;
}): Promise<void> {
  const { error } = await supabase.from('messages').insert({
    conversation_id: input.conversationId,
    sender_id: input.senderId,
    client_id: input.clientId ?? newId(),
    kind: input.kind,
    body: input.body ?? null,
    media_path: input.mediaPath ?? null,
    media_duration_ms: input.durationMs ?? null,
    reply_to_id: input.replyToId ?? null,
    forwarded: input.forwarded ?? false,
  });
  if (error) throw error;
}

export async function markConversationRead(convId: string): Promise<void> {
  const { error } = await supabase.rpc('mark_conversation_read', { conv_id: convId });
  if (error) throw error;
}

export async function toggleReaction(messageId: string, meId: string, emoji: string, current: string | null) {
  if (current === emoji) {
    const { error } = await supabase.from('message_reactions').delete().eq('message_id', messageId).eq('user_id', meId);
    if (error) throw error;
    return;
  }
  const { error } = await supabase
    .from('message_reactions')
    .upsert({ message_id: messageId, user_id: meId, emoji }, { onConflict: 'message_id,user_id' });
  if (error) throw error;
}

export async function deleteMessage(messageId: string) {
  const { error } = await supabase.from('messages').delete().eq('id', messageId);
  if (error) throw error;
}

// Sends a push to another user who shares a conversation with the sender. Never throws, so it never blocks the UI.
export async function notifyUser(recipientId: string, title: string, body: string, data: Record<string, string>) {
  try {
    await supabase.functions.invoke('notify', { body: { recipientId, title, body, data } });
  } catch {}
}

export async function fetchProfileById(userId: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, username, display_name, gender, age, avatar_path, bio, last_seen_at')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw error;
  return (data as Profile) ?? null;
}

// Hides a message for this user only. The other person still sees it.
export async function deleteMessageForMe(messageId: string, meId: string): Promise<void> {
  const { error } = await supabase.from('message_hidden').insert({ message_id: messageId, user_id: meId });
  if (error && error.code !== '23505') throw error;
}

// ---------- Safety: block, unblock, report ----------

export async function blockUser(blockedId: string, meId: string): Promise<void> {
  const { error } = await supabase.from('user_blocks').insert({ blocker_id: meId, blocked_id: blockedId });
  if (error && error.code !== '23505') throw error;
}

export async function unblockUser(blockedId: string, meId: string): Promise<void> {
  const { error } = await supabase.from('user_blocks').delete().eq('blocker_id', meId).eq('blocked_id', blockedId);
  if (error) throw error;
}

export type ReportReason = 'spam' | 'harassment' | 'hate' | 'sexual' | 'violence' | 'impersonation' | 'other';

export async function reportUser(reportedId: string, meId: string, reason: ReportReason, details?: string): Promise<void> {
  const { error } = await supabase.from('user_reports').insert({
    reporter_id: meId,
    reported_id: reportedId,
    reason,
    details: details?.trim() ? details.trim().slice(0, 500) : null,
  });
  if (error) throw error;
}

// ---------- Phase 3: per-user chat settings (mute, archive, pin) ----------

export type ChatPref = { conversation_id: string; muted: boolean; archived: boolean; pinned_message_id: string | null };

export async function getAllChatPrefs(meId: string): Promise<Record<string, ChatPref>> {
  const { data, error } = await supabase
    .from('chat_prefs')
    .select('conversation_id, muted, archived, pinned_message_id')
    .eq('user_id', meId);
  if (error) throw error;
  const map: Record<string, ChatPref> = {};
  (data ?? []).forEach((row) => {
    map[row.conversation_id as string] = row as ChatPref;
  });
  return map;
}

// Reads the current row first, so changing one setting never resets the others.
export async function updateChatPref(meId: string, convId: string, patch: Partial<Omit<ChatPref, 'conversation_id'>>) {
  const { data: current } = await supabase
    .from('chat_prefs')
    .select('muted, archived, pinned_message_id')
    .eq('user_id', meId)
    .eq('conversation_id', convId)
    .maybeSingle();
  const merged = {
    muted: false,
    archived: false,
    pinned_message_id: null as string | null,
    ...(current ?? {}),
    ...patch,
  };
  const { error } = await supabase.from('chat_prefs').upsert(
    { user_id: meId, conversation_id: convId, ...merged, updated_at: new Date().toISOString() },
    { onConflict: 'user_id,conversation_id' },
  );
  if (error) throw error;
}

// ---------- Phase 3: search and forward ----------

export async function searchInChat(convId: string, query: string): Promise<Message[]> {
  const q = query.trim().replace(/[%_\\]/g, '\\$&');
  if (q.length < 2) return [];
  const { data, error } = await supabase
    .from('messages')
    .select('*, message_reactions(emoji, user_id)')
    .eq('conversation_id', convId)
    .ilike('body', `%${q}%`)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return (data ?? []) as unknown as Message[];
}

export async function forwardMessage(sourceId: string, targetConvId: string, meId: string): Promise<void> {
  const { data: src, error } = await supabase
    .from('messages')
    .select('kind, body, media_path, media_duration_ms')
    .eq('id', sourceId)
    .maybeSingle();
  if (error) throw error;
  if (!src) throw new Error('This message is no longer available.');
  await sendMessage({
    conversationId: targetConvId,
    senderId: meId,
    kind: src.kind as MessageKind,
    body: src.body ?? undefined,
    mediaPath: src.media_path ?? undefined,
    durationMs: src.media_duration_ms ?? undefined,
    forwarded: true,
  });
}
