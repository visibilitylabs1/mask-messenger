// Brand: orange, yellow, blue only. Everything else is neutral.
export const colors = {
  orange: '#FF7A1A',
  orangeSoft: '#FFEBDB',
  yellow: '#FFC83D',
  yellowSoft: '#FFF6D6',
  blue: '#2F7BFF',
  blueSoft: '#E4EEFF',
  ink: '#15161A',
  muted: '#6B6F7B',
  faint: '#A3A7B2',
  line: '#ECEDEF',
  bg: '#F7F7F5',
  surface: '#FFFFFF',
  danger: '#E5484D',
  bubbleMine: '#FF7A1A',
  bubbleTheirs: '#FFFFFF',
};

export const radius = { sm: 10, md: 16, lg: 22, pill: 999 };

export const font = {
  regular: 'PlusJakartaSans_400Regular',
  medium: 'PlusJakartaSans_500Medium',
  semibold: 'PlusJakartaSans_600SemiBold',
  bold: 'PlusJakartaSans_700Bold',
};

export const GENDERS = [
  { value: 'female', label: 'Female' },
  { value: 'male', label: 'Male' },
  { value: 'non_binary', label: 'Non-binary' },
  { value: 'other', label: 'Other' },
  { value: 'prefer_not_to_say', label: 'Prefer not to say' },
] as const;
