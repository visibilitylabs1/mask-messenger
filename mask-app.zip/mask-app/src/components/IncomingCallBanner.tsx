import { useEffect } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSession } from '@/src/lib/session';
import { startRingtone, stopTone } from '@/src/lib/sounds';
import { declineCall } from '@/src/lib/calls';
import { colors, font, radius } from '@/src/lib/theme';

export function IncomingCallBanner() {
  const { incomingCall, dismissIncoming } = useSession();
  const router = useRouter();

  // Ring while the banner is visible. Stops when accepted or dismissed.
  useEffect(() => {
    if (!incomingCall) return;
    startRingtone().catch(() => {});
    return () => {
      stopTone();
    };
  }, [incomingCall]);

  if (!incomingCall) return null;

  const decline = () => {
    const call = incomingCall;
    dismissIncoming();
    declineCall(call.conversationId, call.logId ?? null).catch(() => {});
  };

  const accept = () => {
    const call = incomingCall;
    dismissIncoming();
    router.push({
      pathname: '/call/[id]',
      params: { id: call.conversationId, role: 'callee', kind: call.kind, peerId: call.fromId, peerName: call.fromName, logId: call.logId ?? '' },
    });
  };

  return (
    <View style={styles.wrap} pointerEvents="box-none">
      <View style={styles.card}>
        <View style={styles.icon}>
          <Ionicons name={incomingCall.kind === 'video' ? 'videocam' : 'call'} size={20} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>{incomingCall.fromName}</Text>
          <Text style={styles.sub}>Incoming {incomingCall.kind} call</Text>
        </View>
        <Pressable onPress={decline} style={[styles.btn, { backgroundColor: colors.line }]}>
          <Ionicons name="close" size={20} color={colors.ink} />
        </Pressable>
        <Pressable onPress={accept} style={[styles.btn, { backgroundColor: colors.blue }]}>
          <Ionicons name="checkmark" size={22} color="#fff" />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', top: 56, left: 12, right: 12 },
  card: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.surface, borderRadius: radius.lg, padding: 12, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 16, shadowOffset: { width: 0, height: 6 }, elevation: 6 },
  icon: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.orange, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: font.semibold, fontSize: 15, color: colors.ink },
  sub: { fontFamily: font.regular, fontSize: 13, color: colors.muted },
  btn: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
});
