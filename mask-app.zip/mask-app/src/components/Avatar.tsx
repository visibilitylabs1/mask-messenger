import { useEffect, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { signedUrl } from '@/src/lib/media';
import { colors, font } from '@/src/lib/theme';

const palette = [
  { bg: colors.orange, fg: '#FFFFFF' },
  { bg: colors.yellow, fg: colors.ink },
  { bg: colors.blue, fg: '#FFFFFF' },
];

export function Avatar({ name, path, size = 44 }: { name: string; path?: string | null; size?: number }) {
  const [uri, setUri] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    if (path) {
      signedUrl('avatars', path)
        .then((u) => alive && setUri(u))
        .catch(() => alive && setUri(null));
    } else {
      setUri(null);
    }
    return () => {
      alive = false;
    };
  }, [path]);

  const tone = palette[(name.charCodeAt(0) || 0) % palette.length];
  const initials = name.split(' ').map((s) => s[0]).join('').slice(0, 2).toUpperCase() || '?';
  const box = { width: size, height: size, borderRadius: size / 2 };

  if (uri) return <Image source={{ uri }} style={box} contentFit="cover" />;
  return (
    <View style={[styles.fallback, box, { backgroundColor: tone.bg }]}>
      <Text style={{ fontFamily: font.bold, color: tone.fg, fontSize: size * 0.36 }}>{initials}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  fallback: { alignItems: 'center', justifyContent: 'center' },
});
