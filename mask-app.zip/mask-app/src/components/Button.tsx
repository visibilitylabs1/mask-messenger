import { ActivityIndicator, Pressable, StyleSheet, Text, type ViewStyle } from 'react-native';
import * as Haptics from 'expo-haptics';
import { colors, font, radius } from '@/src/lib/theme';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';

export function Button({
  title,
  onPress,
  variant = 'primary',
  loading,
  disabled,
  style,
}: {
  title: string;
  onPress: () => void;
  variant?: Variant;
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
}) {
  const v = variantStyles[variant];
  const inactive = disabled || loading;
  return (
    <Pressable
      onPress={() => {
        Haptics.selectionAsync().catch(() => {});
        onPress();
      }}
      disabled={inactive}
      style={({ pressed }) => [
        styles.base,
        { backgroundColor: v.bg, borderColor: v.border ?? v.bg },
        pressed && !inactive && { opacity: 0.85, transform: [{ scale: 0.99 }] },
        inactive && { opacity: 0.5 },
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={v.fg} />
      ) : (
        <Text style={[styles.text, { color: v.fg }]}>{title}</Text>
      )}
    </Pressable>
  );
}

const variantStyles: Record<Variant, { bg: string; fg: string; border?: string }> = {
  primary: { bg: colors.orange, fg: '#FFFFFF' },
  secondary: { bg: colors.blue, fg: '#FFFFFF' },
  ghost: { bg: colors.surface, fg: colors.ink, border: colors.line },
  danger: { bg: colors.danger, fg: '#FFFFFF' },
};

const styles = StyleSheet.create({
  base: {
    height: 52,
    borderRadius: radius.pill,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  text: { fontFamily: font.semibold, fontSize: 16 },
});
