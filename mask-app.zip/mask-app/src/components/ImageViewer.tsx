import { useEffect, useState } from 'react';
import { ActivityIndicator, Modal, Pressable, StatusBar, StyleSheet, View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { signedUrl } from '@/src/lib/media';

// Full-screen view of a chat image. Tap the X or the background to close.
export function ImageViewer({ path, onClose }: { path: string; onClose: () => void }) {
  const [uri, setUri] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    signedUrl('chat-media', path).then(setUri).catch(() => setFailed(true));
  }, [path]);

  return (
    <Modal visible animationType="fade" transparent presentationStyle="overFullScreen" onRequestClose={onClose} statusBarTranslucent>
      <StatusBar barStyle="light-content" backgroundColor="#000" />
      <View style={styles.backdrop}>
        <Pressable style={StyleSheet.absoluteFill} onPress={onClose} />
        {uri ? (
          <Image source={{ uri }} style={styles.image} contentFit="contain" transition={150} />
        ) : failed ? null : (
          <ActivityIndicator color="#fff" size="large" />
        )}
        <Pressable onPress={onClose} hitSlop={16} style={styles.close}>
          <Ionicons name="close" size={26} color="#fff" />
        </Pressable>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' },
  image: { width: '100%', height: '100%' },
  close: { position: 'absolute', top: 56, right: 20, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.18)', alignItems: 'center', justifyContent: 'center' },
});
