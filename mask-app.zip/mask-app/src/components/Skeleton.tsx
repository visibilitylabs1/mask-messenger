import { useEffect, useRef } from 'react';
import { Animated, StyleSheet, View, type DimensionValue, type ViewStyle } from 'react-native';
import { colors, radius } from '@/src/lib/theme';

// A grey block that softly pulses while content loads. Uses the built-in Animated API, so no extra package.
export function Shimmer({ width, height, round, style }: { width: DimensionValue; height: number; round?: boolean; style?: ViewStyle }) {
  const opacity = useRef(new Animated.Value(0.45)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, { toValue: 1, duration: 700, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 0.45, duration: 700, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);
  return (
    <Animated.View
      style={[{ width, height, borderRadius: round ? height / 2 : radius.sm, backgroundColor: colors.line, opacity }, style]}
    />
  );
}

// Placeholder rows shown while the chat list loads.
export function ChatListSkeleton() {
  return (
    <View style={styles.list}>
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <View key={i} style={styles.row}>
          <Shimmer width={52} height={52} round />
          <View style={{ flex: 1, gap: 8 }}>
            <Shimmer width="55%" height={14} />
            <Shimmer width="80%" height={12} />
          </View>
        </View>
      ))}
    </View>
  );
}

// Alternating bubbles shown while a chat loads.
export function MessagesSkeleton() {
  const widths: Array<DimensionValue> = ['60%', '45%', '70%', '38%', '55%'];
  return (
    <View style={styles.messages}>
      {widths.map((w, i) => (
        <View key={i} style={[styles.bubbleRow, i % 2 === 0 ? styles.left : styles.right]}>
          <Shimmer width={w} height={44} style={{ borderRadius: radius.lg }} />
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  list: { paddingTop: 8 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingVertical: 12 },
  messages: { flex: 1, justifyContent: 'flex-end', paddingHorizontal: 12, paddingBottom: 16, gap: 10 },
  bubbleRow: { flexDirection: 'row' },
  left: { justifyContent: 'flex-start' },
  right: { justifyContent: 'flex-end' },
});
