import { memo, useEffect, useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { Audio } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { signedUrl } from '@/src/lib/media';
import type { Message } from '@/src/lib/api';
import { colors, font, radius } from '@/src/lib/theme';

export type UiMessage = Message & { pending?: boolean; failed?: boolean };
export const QUICK_REACTIONS = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function formatDuration(ms: number) {
  const s = Math.round(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

function ReceiptTicks({ msg }: { msg: UiMessage }) {
  if (msg.failed) return <Ionicons name="alert-circle" size={14} color={colors.danger} />;
  if (msg.pending) return <Ionicons name="time-outline" size={13} color="rgba(255,255,255,0.8)" />;
  if (msg.read_at) return <Ionicons name="checkmark-done" size={15} color={colors.yellow} />;
  if (msg.delivered_at) return <Ionicons name="checkmark-done" size={15} color="rgba(255,255,255,0.85)" />;
  return <Ionicons name="checkmark" size={15} color="rgba(255,255,255,0.85)" />;
}

function ImageContent({ path }: { path: string }) {
  const [uri, setUri] = useState<string | null>(null);
  useEffect(() => {
    signedUrl('chat-media', path).then(setUri).catch(() => setUri(null));
  }, [path]);
  if (!uri) return <View style={styles.imagePlaceholder}><ActivityIndicator /></View>;
  return <Image source={{ uri }} style={styles.image} contentFit="cover" transition={150} />;
}

function VoiceContent({ path, durationMs, mine }: { path: string; durationMs: number | null; mine: boolean }) {
  const [playing, setPlaying] = useState(false);
  const soundRef = useRef<Audio.Sound | null>(null);
  const tone = mine ? '#FFFFFF' : colors.ink;
  useEffect(() => () => { soundRef.current?.unloadAsync().catch(() => {}); }, []);

  const toggle = async () => {
    try {
      if (!soundRef.current) {
        const url = await signedUrl('chat-media', path);
        const { sound } = await Audio.Sound.createAsync({ uri: url });
        soundRef.current = sound;
        sound.setOnPlaybackStatusUpdate((st) => {
          if (st.isLoaded && st.didJustFinish) {
            setPlaying(false);
            sound.setPositionAsync(0);
          }
        });
      }
      if (playing) { await soundRef.current.pauseAsync(); setPlaying(false); }
      else { await soundRef.current.playAsync(); setPlaying(true); }
    } catch {
      setPlaying(false);
    }
  };

  return (
    <Pressable onPress={toggle} style={styles.voice}>
      <Ionicons name={playing ? 'pause' : 'play'} size={22} color={tone} />
      <View style={[styles.voiceBar, { backgroundColor: mine ? 'rgba(255,255,255,0.5)' : colors.line }]} />
      <Text style={[styles.meta, { color: tone }]}>{durationMs ? formatDuration(durationMs) : '0:00'}</Text>
    </Pressable>
  );
}

function MessageBubbleImpl({
  msg, mine, onLongPress, onPress, reactionSummary,
}: {
  msg: UiMessage; mine: boolean; showTail: boolean; onLongPress: () => void; onPress?: () => void;
  reactionSummary: Array<{ emoji: string; count: number }>;
}) {
  const tone = mine ? '#FFFFFF' : colors.ink;
  return (
    <View style={[styles.row, mine ? styles.rowMine : styles.rowTheirs]}>
      <Pressable
        onLongPress={onLongPress}
        onPress={onPress}
        delayLongPress={250}
        style={[styles.bubble, mine ? styles.bubbleMine : styles.bubbleTheirs, msg.kind === 'image' && styles.bubbleImage]}
      >
        {msg.kind === 'text' && <Text style={[styles.body, { color: tone }]}>{msg.body}</Text>}
        {msg.kind === 'image' && msg.media_path && <ImageContent path={msg.media_path} />}
        {msg.kind === 'voice' && msg.media_path && <VoiceContent path={msg.media_path} durationMs={msg.media_duration_ms} mine={mine} />}
        <View style={styles.footer}>
          <Text style={[styles.meta, { color: mine ? 'rgba(255,255,255,0.85)' : colors.muted }]}>{formatTime(msg.created_at)}</Text>
          {mine && <ReceiptTicks msg={msg} />}
        </View>
      </Pressable>
      {reactionSummary.length > 0 && (
        <View style={[styles.reactions, mine ? styles.reactionsMine : styles.reactionsTheirs]}>
          {reactionSummary.map((r) => (
            <Text key={r.emoji} style={styles.reactionChip}>{r.emoji}{r.count > 1 ? ` ${r.count}` : ''}</Text>
          ))}
        </View>
      )}
      {msg.failed && <Text style={styles.failed}>Not sent.</Text>}
    </View>
  );
}

export const MessageBubble = memo(MessageBubbleImpl);

const styles = StyleSheet.create({
  row: { paddingHorizontal: 12, marginVertical: 2 },
  rowMine: { alignItems: 'flex-end' },
  rowTheirs: { alignItems: 'flex-start' },
  bubble: { maxWidth: '78%', borderRadius: radius.lg, paddingHorizontal: 14, paddingVertical: 9 },
  bubbleMine: { backgroundColor: colors.bubbleMine, borderBottomRightRadius: 6 },
  bubbleTheirs: { backgroundColor: colors.bubbleTheirs, borderBottomLeftRadius: 6, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.line },
  bubbleImage: { padding: 4 },
  body: { fontFamily: font.regular, fontSize: 16, lineHeight: 22 },
  footer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 4, marginTop: 2 },
  meta: { fontFamily: font.regular, fontSize: 11 },
  image: { width: 220, height: 220, borderRadius: radius.md },
  imagePlaceholder: { width: 220, height: 220, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg },
  voice: { flexDirection: 'row', alignItems: 'center', gap: 10, width: 220, paddingVertical: 4 },
  voiceBar: { flex: 1, height: 4, borderRadius: 2 },
  reactions: { flexDirection: 'row', gap: 4, marginTop: -6, paddingHorizontal: 6 },
  reactionsMine: { alignSelf: 'flex-end' },
  reactionsTheirs: { alignSelf: 'flex-start' },
  reactionChip: { fontSize: 13, backgroundColor: colors.surface, borderWidth: StyleSheet.hairlineWidth, borderColor: colors.line, borderRadius: radius.pill, paddingHorizontal: 6, paddingVertical: 2, overflow: 'hidden' },
  failed: { fontFamily: font.regular, fontSize: 12, color: colors.danger, marginTop: 2 },
});
