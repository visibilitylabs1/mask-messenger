# Mask — anonymous messenger

React Native + Expo app backed by Supabase (Postgres, Auth, Realtime, Storage, Edge Functions). Calls use WebRTC.

## What is already live in the Supabase project

Project `Mask Project` (ref `wcpktmlxkymuuummtuqs`, eu-north-1):

- Migrations: `mask_core_schema_and_rls`, `mask_private_storage`, `mask_realtime_authorization`, `mask_realtime_topics_presence`
- Tables with RLS: `profiles`, `account_recovery` (no client access), `conversations`, `conversation_members`, `messages`, `message_reactions`
- Private buckets: `avatars`, `chat-media`, with membership-based storage policies
- Realtime channel authorization: conversation topics (`conv:<id>`, `conv:<id>:call`) for members only, personal ring topic (`user:<id>`) for the owner, presence (`online`) for signed-in users
- Edge Functions (JWT checked inside, service-role key never leaves the server):
  - `issue-recovery-code` (auth required): creates a 16-character code, stores only its SHA-256 hash
  - `recover-account` (public, rate limited: 5 wrong codes → 15-minute lock)
  - `delete-account` (auth required): removes stored media, then deletes the auth user, which cascades to profiles, messages, reactions and recovery codes

## One-time setup

1. **Enable anonymous sign-ins.** Supabase dashboard → Authentication → Providers → Anonymous → enable. The app cannot create accounts without this, and I could not switch it on from here.
2. `cp .env.example .env` (the values in it are public and safe to ship).
3. `npm install`
4. Calls use `react-native-webrtc`, which does not run in Expo Go. Build a development client: `npx expo prebuild` then `npx expo run:ios` or `npx expo run:android`.
5. Optional TURN server for calls on strict networks. Put its URL and credentials in `.env`. For production, have a server function issue short-lived TURN credentials instead of shipping a static one.

## Recovery: what it can and cannot do

- The session is kept in the device keychain/keystore. It survives app restarts and updates.
- A reinstall on Android usually loses the session. On iOS the keychain can survive a reinstall, but that is not guaranteed.
- To get back in, the user needs their username and the recovery code. Without the code and without the device, the account cannot be recovered. There is no email or phone to fall back on.
- To sign in with a recovery code, the server gives the anonymous account an internal placeholder email (`<user-id>@accounts.internal.example`). It never receives mail and is never shown in the app. This is the only way to issue a sign-in token without an email address the user owns.

## Status: what has been tested and what has not

Tested against the live database (inside a transaction that was rolled back, so no test data remains):

- 12 security checks pass: username format, one conversation per pair of users, members can read and send, outsiders can neither read nor send, receipts can only be set by the recipient, message bodies cannot be edited, senders cannot be forged, and the recovery table is closed to the API.

Not yet tested (the code is written but I could not run it here):

- The Expo app itself. The container has no network access, so `npm install` and TypeScript checks could not run. Expect some compile fixes on first run.
- Edge Functions end to end (code recovery, account restore, deletion) against a real sign-in.
- Realtime delivery, typing indicators, presence, and receipts across two devices.
- Image and voice note upload and playback on a device.
- Calls. This needs two devices in a development build, and probably a TURN server.
- Session persistence across a real app restart and a reinstall.

## Before release

- Turn on leaked-password protection and rate limits in Supabase Auth.
- Security Advisor (run on the live project): the default `rls_auto_enable` helper is now locked down. Two kinds of warning remain on purpose. `account_recovery` has RLS on and no policies, so only the server can read it. The RPCs that signed-in users call (`get_or_create_direct_conversation`, `mark_conversation_read`, `is_conversation_member`, and the two storage and signal helpers) are SECURITY DEFINER and check `auth.uid()` internally. Moving them to a private schema is a possible later hardening step.
- Decide whether gender and age should stay visible to every signed-in user. Right now they are, because profiles are searchable.
- Confirm the minimum age (13) and the privacy text.
- Add a privacy policy and terms before the app goes to the stores.
