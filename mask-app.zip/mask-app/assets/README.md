Mask app assets (generated from the Mask logo).

- mask-messenger-icon.png: 1024x1024, opaque. Used as the app icon.
- mask-messenger-adaptive.png: 1024x1024, transparent. Android adaptive icon foreground.
- mask-messenger-splash.png: 1284x2778, white. Splash screen.

Rebuild the native app after changing these (a new APK build is needed to see the new icon).
