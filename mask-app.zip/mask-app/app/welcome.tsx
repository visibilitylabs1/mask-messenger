import { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Button } from '@/src/components/Button';
import { signInWithGoogle } from '@/src/lib/google';
import { useRouter } from 'expo-router';
import { colors, font, radius } from '@/src/lib/theme';

export default function Welcome() {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onGoogle = async () => {
    setError(null);
    setBusy(true);
    try {
      // On success the session is set and the route guard takes over.
      await signInWithGoogle();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <View style={styles.screen}>
      <View style={styles.hero}>
        <Image source={require('../assets/mask-messenger-adaptive.png')} style={styles.logo} contentFit="contain" />
        <Text style={styles.title}>Mask</Text>
        <Text style={styles.tagline}>Private conversations.{'\n'}Your identity, your choice.</Text>
      </View>

      <View style={styles.actions}>
        <Button title="Start as guest" onPress={() => router.push('/onboarding')} />
        <Button title="Continue with Google" variant="ghost" onPress={onGoogle} loading={busy} />
        <Text style={styles.note}>No email or phone needed. A guest account lives on this device, so Google sign-in is optional if you want your account to follow you.</Text>
        {error && <Text style={styles.error}>{error}</Text>}
        <View style={styles.points}>
          <Point icon="lock-closed-outline" text="Your chats are private to you and the person you message" />
          <Point icon="person-outline" text="Pick a username. No phone number is needed" />
          <Point icon="refresh-outline" text="Guest data stays on this device. Google sign-in lets it follow you to another phone" />
        </View>
      </View>
    </View>
  );
}

function Point({ icon, text }: { icon: keyof typeof Ionicons.glyphMap; text: string }) {
  return (
    <View style={styles.point}>
      <View style={styles.pointIcon}>
        <Ionicons name={icon} size={18} color={colors.blue} />
      </View>
      <Text style={styles.pointText}>{text}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface, paddingHorizontal: 28, paddingBottom: 40, justifyContent: 'space-between' },
  hero: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  logo: { width: 180, height: 180 },
  title: { fontFamily: font.bold, fontSize: 40, color: colors.ink, letterSpacing: -1, marginTop: 8 },
  tagline: { fontFamily: font.medium, fontSize: 16, color: colors.muted, textAlign: 'center', lineHeight: 23 },
  actions: { gap: 16 },
  error: { fontFamily: font.medium, color: colors.danger, textAlign: 'center', fontSize: 14 },
  note: { fontFamily: font.regular, fontSize: 12, color: colors.muted, textAlign: 'center', lineHeight: 18 },
  points: { gap: 14, marginTop: 12 },
  point: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  pointIcon: { width: 36, height: 36, borderRadius: radius.md, backgroundColor: colors.blueSoft, alignItems: 'center', justifyContent: 'center' },
  pointText: { flex: 1, fontFamily: font.regular, fontSize: 13, color: colors.muted, lineHeight: 18 },
});
