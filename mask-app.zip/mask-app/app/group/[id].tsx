import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { addGroupMembers, fetchGroup, leaveGroup, removeGroupMember, searchUsers, setGroupAdmin, setGroupTitle, type GroupMember } from '@/src/lib/api';
import { useSession } from '@/src/lib/session';
import { colors, font, radius } from '@/src/lib/theme';

// Group info: name, members, roles, add/remove people, rename, and leave.
export default function GroupInfo() {
  const { id: convId } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { profile } = useSession();
  const me = profile?.id ?? '';
  const [title, setTitle] = useState('');
  const [members, setMembers] = useState<GroupMember[] | null>(null);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');
  const [adding, setAdding] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<{ id: string; username: string; display_name: string; avatar_path: string | null }[]>([]);

  const load = useCallback(async () => {
    try {
      const g = await fetchGroup(convId);
      setTitle(g.title);
      setMembers(g.members);
    } catch (e) {
      Alert.alert('Could not load group', (e as Error).message);
    }
  }, [convId]);

  useEffect(() => { load(); }, [load]);

  const mine = members?.find((m) => m.id === me);
  const iAmAdmin = mine?.role === 'admin';

  useEffect(() => {
    if (!profile || query.trim().length < 2) { setResults([]); return; }
    const t = setTimeout(() => {
      searchUsers(query.trim().toLowerCase(), profile.id).then((r) => setResults(r)).catch(() => setResults([]));
    }, 300);
    return () => clearTimeout(t);
  }, [query, profile]);

  const run = async (fn: () => Promise<unknown>) => {
    try { await fn(); await load(); } catch (e) { Alert.alert('Not allowed', (e as Error).message); }
  };

  const saveTitle = () => {
    const t = draft.trim();
    setEditing(false);
    if (!t || t === title) return;
    run(() => setGroupTitle(convId, t));
  };

  const removeMember = (m: GroupMember) => {
    if (m.role === 'admin') return Alert.alert('Remove admin role first', `@${m.username} is an admin.`);
    Alert.alert('Remove from group?', `@${m.username} will no longer see new messages.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => run(() => removeGroupMember(convId, m.id)) },
    ]);
  };

  const memberOptions = (m: GroupMember) => {
    const actions: { text: string; style?: 'cancel' | 'destructive'; onPress?: () => void }[] = [];
    if (m.role === 'member') actions.push({ text: 'Make admin', onPress: () => run(() => setGroupAdmin(convId, m.id, true)) });
    else actions.push({ text: 'Remove admin', onPress: () => run(() => setGroupAdmin(convId, m.id, false)) });
    actions.push({ text: 'Remove from group', style: 'destructive', onPress: () => removeMember(m) });
    actions.push({ text: 'Cancel', style: 'cancel' });
    Alert.alert(`@${m.username}`, undefined, actions);
  };

  const leave = () => {
    Alert.alert('Leave group?', 'You will stop receiving messages from this group.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Leave', style: 'destructive', onPress: async () => {
        try { await leaveGroup(convId); router.replace('/(tabs)/chats'); } catch (e) { Alert.alert('Could not leave', (e as Error).message); }
      } },
    ]);
  };

  const add = (userId: string) => run(async () => {
    await addGroupMembers(convId, [userId]);
    setQuery('');
    setResults([]);
    setAdding(false);
  });

  if (members === null) return <View style={styles.center}><ActivityIndicator color={colors.orange} /></View>;

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 48 }}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={10}><Ionicons name="chevron-back" size={26} color={colors.ink} /></Pressable>
        <Text style={styles.headerTitle}>Group info</Text>
        <View style={{ width: 26 }} />
      </View>

      <View style={styles.hero}>
        <View style={styles.groupIcon}><Ionicons name="people" size={40} color="#fff" /></View>
        {editing ? (
          <TextInput value={draft} onChangeText={setDraft} autoFocus maxLength={60} onSubmitEditing={saveTitle} onBlur={saveTitle} style={styles.nameInput} />
        ) : (
          <Pressable onPress={() => { if (iAmAdmin) { setDraft(title); setEditing(true); } }}>
            <Text style={styles.groupName}>{title}</Text>
          </Pressable>
        )}
        <Text style={styles.count}>{members.length} members{iAmAdmin ? ' · you are an admin' : ''}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.section}>Members</Text>
        {members.map((m) => (
          <Pressable key={m.id} onPress={() => (iAmAdmin && m.id !== me ? memberOptions(m) : undefined)} style={styles.member}>
            <Avatar name={m.display_name} path={m.avatar_path} size={40} />
            <View style={{ flex: 1 }}>
              <Text style={styles.memberName}>{m.display_name}{m.id === me ? ' (you)' : ''}</Text>
              <Text style={styles.memberUser}>@{m.username}</Text>
            </View>
            {m.role === 'admin' && <Text style={styles.adminBadge}>Admin</Text>}
          </Pressable>
        ))}
      </View>

      {iAmAdmin && (
        <View style={styles.card}>
          <Pressable onPress={() => setAdding((a) => !a)} style={styles.action}>
            <Ionicons name="person-add-outline" size={20} color={colors.blue} />
            <Text style={styles.actionText}>Add people</Text>
          </Pressable>
          {adding && (
            <>
              <TextInput value={query} onChangeText={(t) => setQuery(t.replace(/\s/g, '').toLowerCase())} placeholder="Search username" placeholderTextColor={colors.faint} autoCapitalize="none" style={styles.search} />
              {results.filter((r) => !members.some((m) => m.id === r.id)).map((r) => (
                <Pressable key={r.id} onPress={() => add(r.id)} style={styles.member}>
                  <Avatar name={r.display_name} path={r.avatar_path} size={36} />
                  <Text style={styles.memberName}>{r.display_name}</Text>
                  <Ionicons name="add-circle" size={22} color={colors.orange} />
                </Pressable>
              ))}
            </>
          )}
        </View>
      )}

      <View style={styles.card}>
        <Pressable onPress={leave} style={styles.action}>
          <Ionicons name="exit-outline" size={20} color={colors.danger} />
          <Text style={[styles.actionText, { color: colors.danger }]}>Leave group</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, paddingTop: 56 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 10 },
  headerTitle: { fontFamily: font.semibold, fontSize: 17, color: colors.ink },
  hero: { alignItems: 'center', gap: 8, paddingVertical: 16 },
  groupIcon: { width: 84, height: 84, borderRadius: 42, backgroundColor: colors.orange, alignItems: 'center', justifyContent: 'center' },
  groupName: { fontFamily: font.bold, fontSize: 22, color: colors.ink, marginTop: 6 },
  nameInput: { fontFamily: font.bold, fontSize: 22, color: colors.ink, borderBottomWidth: 1, borderBottomColor: colors.orange, minWidth: 200, textAlign: 'center', marginTop: 6 },
  count: { fontFamily: font.regular, fontSize: 13, color: colors.muted },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, marginHorizontal: 16, marginTop: 14, padding: 14, gap: 10 },
  section: { fontFamily: font.semibold, fontSize: 12, color: colors.muted, textTransform: 'uppercase', letterSpacing: 0.5 },
  member: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 4 },
  memberName: { fontFamily: font.semibold, fontSize: 15, color: colors.ink },
  memberUser: { fontFamily: font.regular, fontSize: 12, color: colors.muted },
  adminBadge: { fontFamily: font.semibold, fontSize: 11, color: colors.blue, backgroundColor: colors.blueSoft, paddingHorizontal: 8, paddingVertical: 3, borderRadius: radius.pill, overflow: 'hidden' },
  action: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 6 },
  actionText: { fontFamily: font.semibold, fontSize: 15, color: colors.blue },
  search: { fontFamily: font.regular, fontSize: 15, color: colors.ink, backgroundColor: colors.bg, borderRadius: radius.pill, paddingHorizontal: 14, height: 42, borderWidth: 1, borderColor: colors.line },
});
