import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { Button } from '@/src/components/Button';
import { createGroup, searchUsers } from '@/src/lib/api';
import { useSession } from '@/src/lib/session';
import { colors, font, radius } from '@/src/lib/theme';

type Person = { id: string; username: string; display_name: string; avatar_path: string | null };

// Create a group: a name, then people chosen by username (up to 49 others, 50 in total).
export default function NewGroup() {
  const router = useRouter();
  const { profile } = useSession();
  const [title, setTitle] = useState('');
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Person[]>([]);
  const [chosen, setChosen] = useState<Person[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profile || query.trim().length < 2) { setResults([]); return; }
    const t = setTimeout(() => {
      searchUsers(query.trim().toLowerCase(), profile.id).then((rows) => setResults(rows as Person[])).catch(() => setResults([]));
    }, 300);
    return () => clearTimeout(t);
  }, [query, profile]);

  const toggle = (p: Person) => {
    setChosen((list) => (list.some((x) => x.id === p.id) ? list.filter((x) => x.id !== p.id) : [...list, p]));
  };

  const create = async () => {
    setError(null);
    if (title.trim().length < 1) return setError('Give the group a name.');
    if (chosen.length < 1) return setError('Add at least one person.');
    setBusy(true);
    try {
      const convId = await createGroup(title, chosen.map((p) => p.id));
      router.replace({ pathname: '/chat/[id]', params: { id: convId, peerName: title.trim(), kind: 'group' } });
    } catch (e) {
      Alert.alert('Could not create group', (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={10}><Ionicons name="close" size={26} color={colors.ink} /></Pressable>
        <Text style={styles.headerTitle}>New group</Text>
        <View style={{ width: 26 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 20, gap: 14, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
        <TextInput value={title} onChangeText={setTitle} placeholder="Group name" placeholderTextColor={colors.faint} style={styles.title} maxLength={60} />

        <Text style={styles.label}>Add people by username</Text>
        <TextInput value={query} onChangeText={(t) => setQuery(t.replace(/\s/g, '').toLowerCase())} placeholder="Search username" placeholderTextColor={colors.faint} autoCapitalize="none" autoCorrect={false} style={styles.search} />

        {chosen.length > 0 && (
          <View style={styles.chips}>
            {chosen.map((p) => (
              <Pressable key={p.id} onPress={() => toggle(p)} style={styles.chip}>
                <Text style={styles.chipText}>@{p.username}</Text>
                <Ionicons name="close" size={14} color={colors.blue} />
              </Pressable>
            ))}
          </View>
        )}

        {results.map((p) => {
          const on = chosen.some((x) => x.id === p.id);
          return (
            <Pressable key={p.id} onPress={() => toggle(p)} style={styles.row}>
              <Avatar name={p.display_name} path={p.avatar_path} size={40} />
              <View style={{ flex: 1 }}>
                <Text style={styles.name}>{p.display_name}</Text>
                <Text style={styles.user}>@{p.username}</Text>
              </View>
              <Ionicons name={on ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={on ? colors.orange : colors.faint} />
            </Pressable>
          );
        })}

        {query.trim().length >= 2 && results.length === 0 && <Text style={styles.none}>No one found for "{query}".</Text>}
        {error && <Text style={styles.error}>{error}</Text>}
        <Button title={busy ? 'Creating…' : `Create group (${chosen.length + 1})`} onPress={create} loading={busy} style={{ marginTop: 8 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, paddingTop: 56 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 10 },
  headerTitle: { fontFamily: font.semibold, fontSize: 17, color: colors.ink },
  title: { fontFamily: font.bold, fontSize: 20, color: colors.ink, backgroundColor: colors.surface, borderRadius: radius.md, padding: 14 },
  label: { fontFamily: font.semibold, fontSize: 13, color: colors.muted, textTransform: 'uppercase', letterSpacing: 0.5 },
  search: { fontFamily: font.regular, fontSize: 16, color: colors.ink, backgroundColor: colors.surface, borderRadius: radius.pill, paddingHorizontal: 16, height: 46, borderWidth: 1, borderColor: colors.line },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: radius.pill, backgroundColor: colors.blueSoft },
  chipText: { fontFamily: font.semibold, fontSize: 13, color: colors.blue },
  row: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: colors.surface, borderRadius: radius.md, padding: 12 },
  name: { fontFamily: font.semibold, fontSize: 15, color: colors.ink },
  user: { fontFamily: font.regular, fontSize: 13, color: colors.muted },
  none: { fontFamily: font.regular, fontSize: 14, color: colors.muted },
  error: { fontFamily: font.medium, color: colors.danger, fontSize: 14 },
});
