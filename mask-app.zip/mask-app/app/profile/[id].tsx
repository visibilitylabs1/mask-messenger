import { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Alert } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { blockUser, fetchProfileById, reportUser, type Profile } from '@/src/lib/api';
import { useSession } from '@/src/lib/session';
import { colors, font, radius } from '@/src/lib/theme';

// Public profile: photo, name, username and bio. Age and gender stay private.
export default function ProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { profile: me } = useSession();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    fetchProfileById(id)
      .then((p) => setProfile(p))
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  }, [id]);

  const confirmBlock = () => {
    if (!profile || !me) return;
    Alert.alert(
      `Block @${profile.username}?`,
      'They will not be able to message you, and you will not see their messages. You can unblock later in Settings.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Block',
          style: 'destructive',
          onPress: async () => {
            try {
              await blockUser(profile.id, me.id);
              Alert.alert('Blocked', `@${profile.username} is blocked.`);
            } catch (e) {
              Alert.alert('Could not block', (e as Error).message);
            }
          },
        },
      ],
    );
  };

  const submitReport = async (reason: 'harassment' | 'spam') => {
    if (!profile || !me) return;
    try {
      await reportUser(profile.id, me.id, reason);
      Alert.alert('Report sent', 'Thank you. We will review it.');
    } catch (e) {
      Alert.alert('Could not send report', (e as Error).message);
    }
  };

  const confirmReport = () => {
    Alert.alert('Report this user', 'Why are you reporting them?', [
      { text: 'Harassment', onPress: () => submitReport('harassment') },
      { text: 'Spam', onPress: () => submitReport('spam') },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 48 }}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="chevron-back" size={26} color={colors.ink} />
        </Pressable>
        <Text style={styles.headerTitle}>Profile</Text>
        <View style={{ width: 26 }} />
      </View>

      {loading ? (
        <View style={styles.center}><ActivityIndicator color={colors.orange} /></View>
      ) : error || !profile ? (
        <View style={styles.center}><Text style={styles.error}>{error ?? 'This profile is not available.'}</Text></View>
      ) : (
        <View style={styles.card}>
          <Avatar name={profile.display_name} path={profile.avatar_path} size={120} />
          <Text style={styles.name}>{profile.display_name}</Text>
          <Text style={styles.username}>@{profile.username}</Text>
          {!!profile.bio && <Text style={styles.bio}>{profile.bio}</Text>}
        </View>
      )}
      {profile && me && profile.id !== me.id && (
        <View style={styles.actions}>
          <Pressable onPress={confirmReport} style={styles.actionBtn}>
            <Text style={styles.actionText}>Report</Text>
          </Pressable>
          <Pressable onPress={confirmBlock} style={styles.actionBtn}>
            <Text style={styles.actionDanger}>Block</Text>
          </Pressable>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, paddingTop: 56 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 12 },
  headerTitle: { fontFamily: font.semibold, fontSize: 17, color: colors.ink },
  center: { alignItems: 'center', justifyContent: 'center', padding: 48 },
  error: { fontFamily: font.medium, color: colors.danger, textAlign: 'center' },
  card: { alignItems: 'center', gap: 10, marginHorizontal: 20, marginTop: 24, padding: 24, borderRadius: radius.lg, backgroundColor: colors.surface },
  name: { fontFamily: font.bold, fontSize: 22, color: colors.ink, marginTop: 8 },
  username: { fontFamily: font.medium, fontSize: 15, color: colors.blue },
  bio: { fontFamily: font.regular, fontSize: 14, color: colors.muted, textAlign: 'center', lineHeight: 21, marginTop: 6 },
  actions: { flexDirection: 'row', gap: 12, marginHorizontal: 20, marginTop: 20 },
  actionBtn: { flex: 1, height: 50, borderRadius: radius.pill, backgroundColor: colors.surface, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.line },
  actionText: { fontFamily: font.semibold, fontSize: 15, color: colors.ink },
  actionDanger: { fontFamily: font.semibold, fontSize: 15, color: colors.danger },
});
