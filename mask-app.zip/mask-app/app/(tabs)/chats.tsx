import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { Button } from '@/src/components/Button';
import { ChatListSkeleton } from '@/src/components/Skeleton';
import { getAllChatPrefs, loadChats, searchUsers, updateChatPref, type ChatPref, type ChatSummary } from '@/src/lib/api';
import { useSession } from '@/src/lib/session';
import { supabase } from '@/src/lib/supabase';
import { colors, font, radius } from '@/src/lib/theme';

type Person = { id: string; username: string; display_name: string; avatar_path: string | null };

function previewOf(c: ChatSummary) {
  if (c.lastKind === 'image') return '📷 Photo';
  if (c.lastKind === 'voice') return '🎤 Voice note';
  if (c.lastKind === 'text') return c.lastBody ?? '';
  return 'No messages yet';
}

function timeLabel(iso: string) {
  if (iso.startsWith('1970')) return '';
  const d = new Date(iso);
  return d.toDateString() === new Date().toDateString()
    ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

export default function Chats() {
  const router = useRouter();
  const { profile, onlineIds } = useSession();
  const me = profile?.id ?? '';
  const [items, setItems] = useState<ChatSummary[] | null>(null);
  const [prefs, setPrefs] = useState<Record<string, ChatPref>>({});
  const [showArchived, setShowArchived] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [query, setQuery] = useState('');
  const [people, setPeople] = useState<Person[]>([]);

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      setError(null);
      const [list, p] = await Promise.all([loadChats(profile.id), getAllChatPrefs(profile.id)]);
      setItems(list);
      setPrefs(p);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setRefreshing(false);
    }
  }, [profile]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  useEffect(() => {
    if (!profile) return;
    const ch = supabase.channel(`chat-list:${profile.id}`).on('postgres_changes', { event: '*', schema: 'public', table: 'messages' }, () => load()).subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [profile, load]);

  // Search: filters your chats by name or username, and finds new people by username.
  useEffect(() => {
    const term = query.trim().toLowerCase();
    if (term.length < 2 || !me) {
      setPeople([]);
      return;
    }
    const t = setTimeout(() => {
      searchUsers(term, me).then((rows) => setPeople(rows as Person[])).catch(() => setPeople([]));
    }, 300);
    return () => clearTimeout(t);
  }, [query, me]);

  const visible = useMemo(() => {
    if (!items) return [];
    const term = query.trim().toLowerCase();
    return items.filter((c) => {
      const archived = !!prefs[c.conversationId]?.archived;
      if (archived !== showArchived) return false;
      if (term.length === 0) return true;
      return c.other.display_name.toLowerCase().includes(term) || c.other.username.toLowerCase().includes(term);
    });
  }, [items, prefs, showArchived, query]);

  const archivedCount = useMemo(() => (items ?? []).filter((c) => prefs[c.conversationId]?.archived).length, [items, prefs]);

  const openActions = (c: ChatSummary) => {
    if (!profile) return;
    const p = prefs[c.conversationId];
    const muted = !!p?.muted;
    const archived = !!p?.archived;
    Alert.alert(c.other.display_name, undefined, [
      {
        text: muted ? 'Unmute' : 'Mute',
        onPress: async () => {
          try { await updateChatPref(profile.id, c.conversationId, { muted: !muted }); await load(); }
          catch (e) { Alert.alert('Could not update', (e as Error).message); }
        },
      },
      {
        text: archived ? 'Unarchive' : 'Archive',
        onPress: async () => {
          try { await updateChatPref(profile.id, c.conversationId, { archived: !archived }); await load(); }
          catch (e) { Alert.alert('Could not update', (e as Error).message); }
        },
      },
      { text: 'Cancel', style: 'cancel' },
    ]);
  };

  const openPerson = (person: Person) => {
    router.push({ pathname: '/profile/[id]', params: { id: person.id } });
  };

  if (items === null && !error) return <ChatListSkeleton />;

  if (error && items === null) {
    return (
      <View style={styles.center}>
        <Text style={styles.errorText}>Could not load chats. {error}</Text>
        <Button title="Try again" onPress={load} style={{ marginTop: 16 }} />
      </View>
    );
  }

  const searching = query.trim().length > 0;

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <Text style={styles.title}>{showArchived ? 'Archived' : 'Chats'}</Text>
        <View style={styles.headerActions}>
          <Pressable onPress={() => router.push('/group/new')} hitSlop={8} style={styles.headerBtn}>
            <Ionicons name="create-outline" size={20} color={colors.blue} />
          </Pressable>
          <Pressable onPress={() => router.push('/calls')} hitSlop={8} style={styles.headerBtn}>
            <Ionicons name="call-outline" size={20} color={colors.blue} />
          </Pressable>
          {showArchived && (
            <Pressable onPress={() => setShowArchived(false)} hitSlop={8}>
              <Text style={styles.link}>Done</Text>
            </Pressable>
          )}
        </View>
      </View>

      <View style={styles.searchBox}>
        <Ionicons name="search" size={16} color={colors.muted} />
        <TextInput
          value={query}
          onChangeText={(t) => setQuery(t.replace(/\s/g, ''))}
          placeholder="Search chats and people"
          placeholderTextColor={colors.faint}
          autoCapitalize="none"
          autoCorrect={false}
          style={styles.searchInput}
        />
        {searching && (
          <Pressable onPress={() => setQuery('')} hitSlop={8}>
            <Ionicons name="close-circle" size={18} color={colors.faint} />
          </Pressable>
        )}
      </View>

      {!showArchived && !searching && archivedCount > 0 && (
        <Pressable onPress={() => setShowArchived(true)} style={styles.archivedRow}>
          <Ionicons name="archive-outline" size={20} color={colors.blue} />
          <Text style={styles.archivedText}>Archived ({archivedCount})</Text>
        </Pressable>
      )}

      {searching && people.length > 0 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.peopleRow}>
          {people.map((p) => (
            <Pressable key={p.id} onPress={() => openPerson(p)} style={styles.personChip}>
              <Avatar name={p.display_name} path={p.avatar_path} size={36} />
              <Text style={styles.personName} numberOfLines={1}>{p.display_name}</Text>
              <Text style={styles.personUser} numberOfLines={1}>@{p.username}</Text>
            </Pressable>
          ))}
        </ScrollView>
      )}

      <FlatList
        data={visible}
        keyExtractor={(c) => c.conversationId}
        contentContainerStyle={{ paddingBottom: 24, flexGrow: 1 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={colors.orange} />}
        ListEmptyComponent={
          searching ? (
            <Text style={styles.emptySub}>No chats match "{query}".</Text>
          ) : showArchived ? (
            <Text style={styles.emptySub}>No archived chats.</Text>
          ) : (
            <View style={styles.empty}>
              <View style={styles.emptyIcon}><Ionicons name="chatbubble-ellipses-outline" size={34} color={colors.orange} /></View>
              <Text style={styles.emptyTitle}>No chats yet</Text>
              <Text style={styles.emptySub}>Search for someone by username above to start a chat.</Text>
            </View>
          )
        }
        renderItem={({ item }) => {
          const online = onlineIds.has(item.other.id);
          const p = prefs[item.conversationId];
          return (
            <Pressable
              onPress={() => router.push({ pathname: '/chat/[id]', params: { id: item.conversationId, peerId: item.other.id, peerName: item.other.display_name, kind: item.kind ?? 'direct' } })}
              onLongPress={() => openActions(item)}
              delayLongPress={300}
              style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.bg }]}
            >
              <View>
                <Avatar name={item.other.display_name} path={item.other.avatar_path} size={52} />
                {online && <View style={styles.online} />}
              </View>
              <View style={{ flex: 1, minWidth: 0 }}>
                <View style={styles.rowTop}>
                  <Text style={styles.name} numberOfLines={1}>{item.other.display_name}</Text>
                  <Text style={[styles.time, item.unread > 0 && !p?.muted && { color: colors.orange }]}>{timeLabel(item.lastAt)}</Text>
                </View>
                <View style={styles.rowBottom}>
                  <Text style={styles.preview} numberOfLines={1}>{previewOf(item)}</Text>
                  {p?.muted && <Ionicons name="notifications-off-outline" size={15} color={colors.faint} />}
                  {item.unread > 0 && (
                    <View style={[styles.badge, p?.muted && { backgroundColor: colors.faint }]}>
                      <Text style={styles.badgeText}>{item.unread > 99 ? '99+' : item.unread}</Text>
                    </View>
                  )}
                </View>
              </View>
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface, paddingTop: 56 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 10 },
  headerActions: { flexDirection: 'row', alignItems: 'center', gap: 14 },
  headerBtn: { width: 38, height: 38, borderRadius: 19, backgroundColor: colors.blueSoft, alignItems: 'center', justifyContent: 'center' },
  title: { fontFamily: font.bold, fontSize: 30, color: colors.ink, letterSpacing: -0.6 },
  link: { fontFamily: font.semibold, fontSize: 15, color: colors.blue },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 16, height: 42, paddingHorizontal: 14, borderRadius: radius.pill, backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.line },
  searchInput: { flex: 1, fontFamily: font.regular, fontSize: 15, color: colors.ink },
  archivedRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingHorizontal: 20, paddingVertical: 12 },
  archivedText: { fontFamily: font.semibold, fontSize: 15, color: colors.blue },
  peopleRow: { gap: 10, paddingHorizontal: 16, paddingVertical: 12 },
  personChip: { width: 92, alignItems: 'center', gap: 4, padding: 10, borderRadius: radius.lg, backgroundColor: colors.bg },
  personName: { fontFamily: font.semibold, fontSize: 13, color: colors.ink, maxWidth: 80 },
  personUser: { fontFamily: font.regular, fontSize: 11, color: colors.muted, maxWidth: 80 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24, backgroundColor: colors.surface },
  errorText: { fontFamily: font.medium, color: colors.danger, textAlign: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingVertical: 12 },
  online: { position: 'absolute', right: 1, bottom: 1, width: 13, height: 13, borderRadius: 7, backgroundColor: colors.blue, borderWidth: 2, borderColor: colors.surface },
  rowTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  rowBottom: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 3, gap: 8 },
  name: { fontFamily: font.semibold, fontSize: 16, color: colors.ink, flexShrink: 1 },
  time: { fontFamily: font.regular, fontSize: 12, color: colors.faint },
  preview: { fontFamily: font.regular, fontSize: 14, color: colors.muted, flex: 1 },
  badge: { minWidth: 22, height: 22, borderRadius: 11, backgroundColor: colors.orange, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 6 },
  badgeText: { fontFamily: font.bold, fontSize: 12, color: '#fff' },
  empty: { alignItems: 'center', paddingTop: 80, paddingHorizontal: 40 },
  emptyIcon: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.orangeSoft, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontFamily: font.bold, fontSize: 18, color: colors.ink, marginTop: 16 },
  emptySub: { fontFamily: font.regular, fontSize: 14, color: colors.muted, textAlign: 'center', marginTop: 6, lineHeight: 20, paddingHorizontal: 40 },
});
