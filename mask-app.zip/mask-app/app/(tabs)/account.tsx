import { useState } from 'react';
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Avatar } from '@/src/components/Avatar';
import { Button } from '@/src/components/Button';
import { deleteAccount } from '@/src/lib/api';
import { signOutOfGoogle } from '@/src/lib/google';
import { unregisterPush } from '@/src/lib/push';
import { useSession } from '@/src/lib/session';
import { supabase } from '@/src/lib/supabase';
import { colors, font, radius } from '@/src/lib/theme';

export default function Settings() {
  const { profile, session } = useSession();
  const [busy, setBusy] = useState<'signout' | 'delete' | null>(null);
  const email = session?.user.email ?? '';

  // Signing out is deliberate. Your account is tied to your Google account, so signing back in restores everything.
  const signOut = () => {
    Alert.alert(
      'Sign out?',
      'You can sign back in anytime with the same Google account, and your chats will be right here.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Sign out',
          onPress: async () => {
            setBusy('signout');
            if (profile) await unregisterPush(profile.id).catch(() => {});
            await signOutOfGoogle();
            await supabase.auth.signOut();
            setBusy(null);
          },
        },
      ],
    );
  };

  const removeAccount = () => {
    Alert.alert(
      'Delete account permanently?',
      'This deletes your profile, photo, messages you sent, and reactions. It cannot be undone. Your Google account itself is not affected.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete forever',
          style: 'destructive',
          onPress: () =>
            Alert.alert('Are you sure?', 'This cannot be undone.', [
              { text: 'Cancel', style: 'cancel' },
              {
                text: 'Yes, delete',
                style: 'destructive',
                onPress: async () => {
                  setBusy('delete');
                  try {
                    await signOutOfGoogle();
                    await deleteAccount();
                  } catch (e) {
                    Alert.alert('Could not delete account', (e as Error).message);
                  } finally {
                    setBusy(null);
                  }
                },
              },
            ]),
        },
      ],
    );
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 48 }}>
      <Text style={styles.title}>Account</Text>

      <View style={styles.profile}>
        <Avatar name={profile?.display_name ?? '?'} path={profile?.avatar_path} size={68} />
        <View style={{ flex: 1 }}>
          <Text style={styles.name}>{profile?.display_name}</Text>
          <Text style={styles.username}>@{profile?.username}</Text>
          {!!email && <Text style={styles.email}>{email}</Text>}
        </View>
      </View>

      <Section title="Account">
        <Text style={styles.hint}>{email ? 'Signed in with Google. Your chats stay on your account, even after you reinstall the app.' : 'Guest account. It lives on this device only. Uninstalling the app or clearing data removes it for good, and signing out does too.'}</Text>
        <Button title="Sign out" variant="ghost" onPress={signOut} loading={busy === 'signout'} />
      </Section>

      <Section title="Danger zone">
        <Button title="Delete account" variant="danger" onPress={removeAccount} loading={busy === 'delete'} />
      </Section>

      <Text style={styles.version}>Mask 2.1.0</Text>
    </ScrollView>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.card}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg, paddingTop: 56 },
  title: { fontFamily: font.bold, fontSize: 30, color: colors.ink, letterSpacing: -0.6, paddingHorizontal: 20, marginBottom: 16 },
  profile: { flexDirection: 'row', alignItems: 'center', gap: 16, marginHorizontal: 20, padding: 18, borderRadius: radius.lg, backgroundColor: colors.surface },
  name: { fontFamily: font.bold, fontSize: 18, color: colors.ink },
  username: { fontFamily: font.medium, fontSize: 14, color: colors.blue, marginTop: 2 },
  email: { fontFamily: font.regular, fontSize: 12, color: colors.muted, marginTop: 2 },
  section: { marginHorizontal: 20, marginTop: 24, gap: 8 },
  sectionTitle: { fontFamily: font.semibold, fontSize: 12, color: colors.muted, textTransform: 'uppercase', letterSpacing: 0.6, marginLeft: 4 },
  card: { backgroundColor: colors.surface, borderRadius: radius.lg, padding: 16, gap: 12 },
  hint: { fontFamily: font.regular, fontSize: 13, color: colors.muted, lineHeight: 19 },
  version: { fontFamily: font.regular, fontSize: 12, color: colors.faint, textAlign: 'center', marginTop: 32 },
});
