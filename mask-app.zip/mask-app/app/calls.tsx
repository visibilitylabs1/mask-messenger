import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { useSession } from '@/src/lib/session';
import { supabase } from '@/src/lib/supabase';
import { colors, font } from '@/src/lib/theme';

type Log = {
  id: string;
  conversation_id: string;
  caller_id: string;
  callee_id: string;
  kind: 'audio' | 'video';
  status: 'ringing' | 'answered' | 'ended' | 'rejected' | 'missed' | 'failed';
  duration_seconds: number;
  started_at: string;
};
type Person = { id: string; display_name: string; avatar_path: string | null };

function durationLabel(s: number) {
  if (!s) return '';
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}m ${r}s` : `${r}s`;
}

function whenLabel(iso: string) {
  const d = new Date(iso);
  const sameDay = d.toDateString() === new Date().toDateString();
  return sameDay
    ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
}

// Call history: every call you made or received, with the outcome and length.
export default function Calls() {
  const router = useRouter();
  const { profile } = useSession();
  const me = profile?.id ?? '';
  const [logs, setLogs] = useState<Log[] | null>(null);
  const [people, setPeople] = useState<Record<string, Person>>({});
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!me) return;
    try {
      setError(null);
      const { data, error: err } = await supabase
        .from('call_logs')
        .select('id, conversation_id, caller_id, callee_id, kind, status, duration_seconds, started_at')
        .or(`caller_id.eq.${me},callee_id.eq.${me}`)
        .order('started_at', { ascending: false })
        .limit(100);
      if (err) throw err;
      const rows = (data ?? []) as Log[];
      setLogs(rows);
      const ids = [...new Set(rows.map((r) => (r.caller_id === me ? r.callee_id : r.caller_id)))];
      if (ids.length) {
        const { data: ppl } = await supabase.from('profiles').select('id, display_name, avatar_path').in('id', ids);
        const map: Record<string, Person> = {};
        (ppl ?? []).forEach((p) => { map[p.id as string] = p as Person; });
        setPeople(map);
      }
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setRefreshing(false);
    }
  }, [me]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  const callBack = (log: Log) => {
    const otherId = log.caller_id === me ? log.callee_id : log.caller_id;
    router.push({
      pathname: '/call/[id]',
      params: { id: log.conversation_id, role: 'caller', kind: log.kind, peerId: otherId, peerName: people[otherId]?.display_name ?? '' },
    });
  };

  if (logs === null && !error) {
    return <View style={styles.center}><ActivityIndicator color={colors.orange} /></View>;
  }

  return (
    <View style={styles.screen}>
      <View style={styles.topRow}>
        <Pressable onPress={() => router.back()} hitSlop={10}><Ionicons name="chevron-back" size={26} color={colors.ink} /></Pressable>
        <Text style={styles.title}>Calls</Text>
        <View style={{ width: 26 }} />
      </View>
      <FlatList
        data={logs ?? []}
        keyExtractor={(l) => l.id}
        contentContainerStyle={{ paddingBottom: 24, flexGrow: 1 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={colors.orange} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>{error ? 'Could not load calls' : 'No calls yet'}</Text>
            <Text style={styles.emptySub}>{error ?? 'Your audio and video calls will show up here.'}</Text>
          </View>
        }
        renderItem={({ item }) => {
          const outgoing = item.caller_id === me;
          const otherId = outgoing ? item.callee_id : item.caller_id;
          const person = people[otherId];
          const missed = item.status === 'missed' || item.status === 'rejected' || item.status === 'failed';
          const icon: keyof typeof Ionicons.glyphMap = missed
            ? 'arrow-down-outline'
            : outgoing ? 'arrow-up-outline' : 'arrow-down-outline';
          return (
            <Pressable onPress={() => callBack(item)} style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.bg }]}>
              <Avatar name={person?.display_name ?? '?'} path={person?.avatar_path ?? null} size={48} />
              <View style={{ flex: 1, minWidth: 0 }}>
                <Text style={[styles.name, missed && { color: colors.danger }]} numberOfLines={1}>{person?.display_name ?? 'Unknown'}</Text>
                <View style={styles.subRow}>
                  <Ionicons name={icon} size={14} color={missed ? colors.danger : colors.muted} />
                  <Text style={styles.sub} numberOfLines={1}>
                    {item.kind === 'video' ? 'Video' : 'Audio'} · {outcomeLabel(item.status)}{item.duration_seconds ? ` · ${durationLabel(item.duration_seconds)}` : ''}
                  </Text>
                </View>
              </View>
              <Text style={styles.time}>{whenLabel(item.started_at)}</Text>
              <Ionicons name={item.kind === 'video' ? 'videocam-outline' : 'call-outline'} size={20} color={colors.blue} />
            </Pressable>
          );
        }}
      />
    </View>
  );
}

function outcomeLabel(s: Log['status']) {
  switch (s) {
    case 'answered': return 'Answered';
    case 'ended': return 'Ended';
    case 'missed': return 'Missed';
    case 'rejected': return 'Declined';
    case 'failed': return 'Failed';
    default: return 'Ringing';
  }
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface, paddingTop: 56 },
  title: { fontFamily: font.bold, fontSize: 30, color: colors.ink, letterSpacing: -0.6 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingBottom: 12 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingVertical: 12 },
  name: { fontFamily: font.semibold, fontSize: 16, color: colors.ink },
  subRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 3 },
  sub: { fontFamily: font.regular, fontSize: 13, color: colors.muted, flexShrink: 1 },
  time: { fontFamily: font.regular, fontSize: 12, color: colors.faint },
  empty: { alignItems: 'center', paddingTop: 80, paddingHorizontal: 40 },
  emptyTitle: { fontFamily: font.bold, fontSize: 18, color: colors.ink },
  emptySub: { fontFamily: font.regular, fontSize: 14, color: colors.muted, textAlign: 'center', marginTop: 6, lineHeight: 20 },
});
