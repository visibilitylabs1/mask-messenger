import { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { searchUsers, startDirectChat } from '@/src/lib/api';
import { useSession } from '@/src/lib/session';
import { colors, font, radius } from '@/src/lib/theme';

type Result = { id: string; username: string; display_name: string; avatar_path: string | null };

export default function Search() {
  const router = useRouter();
  const { profile } = useSession();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openingId, setOpeningId] = useState<string | null>(null);

  // Debounced search by username prefix.
  useEffect(() => {
    if (!profile) return;
    const q = query.trim();
    if (q.length < 2) {
      setResults([]);
      setError(null);
      return;
    }
    let cancelled = false;
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const rows = await searchUsers(q, profile.id);
        if (!cancelled) {
          setResults(rows as Result[]);
          setError(null);
        }
      } catch (e) {
        if (!cancelled) setError((e as Error).message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [query, profile]);

  const open = async (user: Result) => {
    setOpeningId(user.id);
    try {
      const convId = await startDirectChat(user.id);
      router.push({ pathname: '/chat/[id]', params: { id: convId, peerId: user.id, peerName: user.display_name } });
    } catch (e) {
      Alert.alert('Could not open chat', (e as Error).message);
    } finally {
      setOpeningId(null);
    }
  };

  return (
    <View style={styles.screen}>
      <View style={styles.topRow}>
        <Pressable onPress={() => router.back()} hitSlop={10}><Ionicons name="chevron-back" size={26} color={colors.ink} /></Pressable>
        <Text style={styles.title}>Find people</Text>
        <View style={{ width: 26 }} />
      </View>
      <View style={styles.searchBox}>
        <Ionicons name="search" size={18} color={colors.muted} />
        <TextInput
          value={query}
          onChangeText={(t) => setQuery(t.replace(/\s/g, '').toLowerCase())}
          placeholder="Search by username"
          placeholderTextColor={colors.faint}
          autoCapitalize="none"
          autoCorrect={false}
          style={styles.input}
          returnKeyType="search"
        />
        {loading && <ActivityIndicator size="small" color={colors.orange} />}
      </View>

      {error && <Text style={styles.error}>{error}</Text>}

      <FlatList
        data={results}
        keyExtractor={(u) => u.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{ paddingBottom: 24 }}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>{query.length < 2 ? 'Type a username' : loading ? '' : 'No one found'}</Text>
            <Text style={styles.emptySub}>
              {query.length < 2
                ? 'Usernames are unique. Ask a friend for theirs, then search it here.'
                : 'Check the spelling. Usernames are lowercase letters, numbers and underscores.'}
            </Text>
          </View>
        }
        renderItem={({ item }) => (
          <Pressable onPress={() => open(item)} disabled={openingId !== null} style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.bg }]}>
            <Avatar name={item.display_name} path={item.avatar_path} size={48} />
            <View style={{ flex: 1 }}>
              <Text style={styles.name} numberOfLines={1}>{item.display_name}</Text>
              <Text style={styles.username}>@{item.username}</Text>
            </View>
            {openingId === item.id ? (
              <ActivityIndicator color={colors.orange} />
            ) : (
              <Ionicons name="chatbubble-outline" size={20} color={colors.blue} />
            )}
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface, paddingTop: 56, paddingHorizontal: 20 },
  title: { fontFamily: font.bold, fontSize: 30, color: colors.ink, letterSpacing: -0.6 },
  topRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 10, height: 48, borderRadius: radius.pill, backgroundColor: colors.bg, paddingHorizontal: 16, borderWidth: 1, borderColor: colors.line },
  input: { flex: 1, fontFamily: font.regular, fontSize: 16, color: colors.ink, height: 46 },
  error: { fontFamily: font.medium, color: colors.danger, marginTop: 12 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 12, paddingHorizontal: 4, borderRadius: radius.md },
  name: { fontFamily: font.semibold, fontSize: 16, color: colors.ink },
  username: { fontFamily: font.regular, fontSize: 14, color: colors.muted, marginTop: 2 },
  empty: { alignItems: 'center', paddingTop: 60, paddingHorizontal: 24 },
  emptyTitle: { fontFamily: font.semibold, fontSize: 16, color: colors.ink },
  emptySub: { fontFamily: font.regular, fontSize: 14, color: colors.muted, textAlign: 'center', marginTop: 6, lineHeight: 20 },
});
