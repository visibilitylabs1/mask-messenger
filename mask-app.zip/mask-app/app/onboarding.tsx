import { useState } from 'react';
import { Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { Button } from '@/src/components/Button';
import { GENDERS, colors, font, radius } from '@/src/lib/theme';
import { createProfile, validateUsername } from '@/src/lib/api';
import { pickAvatar, uploadAvatar } from '@/src/lib/media';
import { supabase } from '@/src/lib/supabase';
import { useSession } from '@/src/lib/session';

export default function Onboarding() {
  const { refreshProfile } = useSession();
  const [avatarUri, setAvatarUri] = useState<string | null>(null);
  const [displayName, setDisplayName] = useState('');
  const [username, setUsername] = useState('');
  const [gender, setGender] = useState<string | null>(null);
  const [age, setAge] = useState('');
  const [bio, setBio] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const choosePhoto = async () => {
    try {
      const uri = await pickAvatar();
      if (uri) setAvatarUri(uri);
    } catch (e) {
      Alert.alert('Photo', (e as Error).message);
    }
  };

  const submit = async () => {
    setError(null);
    const name = displayName.trim();
    if (name.length < 1 || name.length > 40) return setError('Enter a name (up to 40 characters).');
    const usernameErr = validateUsername(username);
    if (usernameErr) return setError(usernameErr);
    if (!gender) return setError('Choose a gender option.');
    const ageNum = Number(age);
    if (!Number.isInteger(ageNum) || ageNum < 13 || ageNum > 120) return setError('Age must be between 13 and 120.');

    setBusy(true);
    try {
      // Guests get an anonymous session here. Google users already have one.
      let { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        const { data, error: anonErr } = await supabase.auth.signInAnonymously();
        if (anonErr) throw anonErr;
        session = data.session;
      }
      const userId = session?.user.id;
      if (!userId) throw new Error('Could not start a session. Please try again.');
      const avatarPath = avatarUri ? await uploadAvatar(userId, avatarUri) : null;
      await createProfile({ username, displayName: name, gender, age: ageNum, bio, avatarPath });
      // Refreshing the profile lets the route guard move the user into the app.
      await refreshProfile();
    } finally {
      setBusy(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.surface }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView contentContainerStyle={styles.wrap} keyboardShouldPersistTaps="handled">
        <Text style={styles.step}>Almost there</Text>
        <Text style={styles.title}>Set up your profile</Text>
        <Text style={styles.sub}>Pick a username people can find you by. Only your name, username, bio and photo are shown to others.</Text>

        <Pressable onPress={choosePhoto} style={styles.avatarWrap}>
          {avatarUri ? (
            <Image source={{ uri: avatarUri }} style={styles.avatar} contentFit="cover" />
          ) : (
            <View style={[styles.avatar, styles.avatarEmpty]}>
              <Ionicons name="camera-outline" size={26} color={colors.muted} />
            </View>
          )}
          <Text style={styles.link}>{avatarUri ? 'Change photo' : 'Add photo (optional)'}</Text>
        </Pressable>

        <Field label="Name">
          <TextInput value={displayName} onChangeText={setDisplayName} placeholder="How you appear in chats" style={styles.input} maxLength={40} placeholderTextColor={colors.faint} />
        </Field>

        <Field label="Username">
          <TextInput
            value={username}
            onChangeText={(t) => setUsername(t.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
            placeholder="e.g. night_owl"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
            maxLength={20}
            placeholderTextColor={colors.faint}
          />
        </Field>

        <Field label="Gender">
          <View style={styles.chips}>
            {GENDERS.map((g) => {
              const on = gender === g.value;
              return (
                <Pressable key={g.value} onPress={() => setGender(g.value)} style={[styles.chip, on && styles.chipOn]}>
                  <Text style={[styles.chipText, on && { color: '#fff' }]}>{g.label}</Text>
                </Pressable>
              );
            })}
          </View>
        </Field>

        <Field label="Bio">
          <TextInput
            value={bio}
            onChangeText={setBio}
            placeholder="A line about you (optional)"
            style={[styles.input, styles.bioInput]}
            multiline
            maxLength={150}
            placeholderTextColor={colors.faint}
          />
          <Text style={styles.counter}>{bio.length}/150</Text>
        </Field>

        <Field label="Age">
          <TextInput value={age} onChangeText={(t) => setAge(t.replace(/\D/g, '').slice(0, 3))} keyboardType="number-pad" placeholder="13 or older" style={styles.input} placeholderTextColor={colors.faint} />
        </Field>

        {error && <Text style={styles.error}>{error}</Text>}

        <Button title="Register" onPress={submit} loading={busy} style={{ marginTop: 24 }} />
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <View style={{ gap: 8, marginTop: 18 }}>
      <Text style={styles.label}>{label}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { padding: 24, paddingTop: 72, paddingBottom: 48 },
  step: { fontFamily: font.semibold, fontSize: 13, color: colors.orange, textTransform: 'uppercase', letterSpacing: 0.6 },
  title: { fontFamily: font.bold, fontSize: 28, color: colors.ink, marginTop: 6, letterSpacing: -0.5 },
  sub: { fontFamily: font.regular, fontSize: 15, color: colors.muted, marginTop: 6, lineHeight: 22 },
  avatarWrap: { alignItems: 'center', marginTop: 24, gap: 8 },
  avatar: { width: 96, height: 96, borderRadius: 48 },
  avatarEmpty: { backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: colors.line, borderStyle: 'dashed' },
  link: { fontFamily: font.medium, color: colors.blue, fontSize: 14 },
  label: { fontFamily: font.semibold, fontSize: 13, color: colors.ink },
  input: { height: 52, borderRadius: radius.md, borderWidth: 1, borderColor: colors.line, paddingHorizontal: 16, fontFamily: font.regular, fontSize: 16, color: colors.ink, backgroundColor: colors.bg },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 9, borderRadius: radius.pill, borderWidth: 1, borderColor: colors.line, backgroundColor: colors.surface },
  chipOn: { backgroundColor: colors.orange, borderColor: colors.orange },
  chipText: { fontFamily: font.medium, fontSize: 14, color: colors.ink },
  error: { fontFamily: font.medium, color: colors.danger, marginTop: 16, fontSize: 14 },
  bioInput: { height: 88, paddingTop: 14, textAlignVertical: 'top' },
  counter: { alignSelf: 'flex-end', fontFamily: font.regular, fontSize: 12, color: colors.faint },
});
