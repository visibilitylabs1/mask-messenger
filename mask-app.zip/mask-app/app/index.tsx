import { ActivityIndicator, View } from 'react-native';
import { colors } from '@/src/lib/theme';

// The guard in _layout.tsx sends the user to the right screen. This only shows while it decides.
export default function Index() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface }}>
      <ActivityIndicator color={colors.orange} />
    </View>
  );
}
