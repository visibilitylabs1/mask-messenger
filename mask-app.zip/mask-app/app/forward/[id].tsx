import { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { forwardMessage, loadChats, type ChatSummary } from '@/src/lib/api';
import { useSession } from '@/src/lib/session';
import { colors, font } from '@/src/lib/theme';

// Choose which chat to forward a message to.
export default function ForwardScreen() {
  const { id: messageId } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { profile } = useSession();
  const [chats, setChats] = useState<ChatSummary[] | null>(null);
  const [sendingTo, setSendingTo] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    loadChats(profile.id).then(setChats).catch(() => setChats([]));
  }, [profile]);

  const send = async (conv: ChatSummary) => {
    if (!profile) return;
    setSendingTo(conv.conversationId);
    try {
      await forwardMessage(messageId, conv.conversationId, profile.id);
      Alert.alert('Forwarded', `Sent to ${conv.other.display_name}.`, [{ text: 'OK', onPress: () => router.back() }]);
    } catch (e) {
      Alert.alert('Could not forward', (e as Error).message);
    } finally {
      setSendingTo(null);
    }
  };

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={12}>
          <Ionicons name="close" size={26} color={colors.ink} />
        </Pressable>
        <Text style={styles.title}>Forward to</Text>
        <View style={{ width: 26 }} />
      </View>

      {chats === null ? (
        <View style={styles.center}><ActivityIndicator color={colors.orange} /></View>
      ) : (
        <FlatList
          data={chats}
          keyExtractor={(c) => c.conversationId}
          ListEmptyComponent={<Text style={styles.empty}>You have no chats yet.</Text>}
          renderItem={({ item }) => (
            <Pressable onPress={() => send(item)} disabled={sendingTo !== null} style={({ pressed }) => [styles.row, pressed && { backgroundColor: colors.bg }]}>
              <Avatar name={item.other.display_name} path={item.other.avatar_path} size={44} />
              <Text style={styles.name} numberOfLines={1}>{item.other.display_name}</Text>
              {sendingTo === item.conversationId && <ActivityIndicator color={colors.orange} />}
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.surface, paddingTop: 56 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingBottom: 12 },
  title: { fontFamily: font.semibold, fontSize: 17, color: colors.ink },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { fontFamily: font.regular, fontSize: 14, color: colors.muted, textAlign: 'center', marginTop: 40 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingHorizontal: 20, paddingVertical: 12 },
  name: { flex: 1, fontFamily: font.semibold, fontSize: 16, color: colors.ink },
});
