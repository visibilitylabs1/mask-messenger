import { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import { Stack, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import {
  PlusJakartaSans_400Regular,
  PlusJakartaSans_500Medium,
  PlusJakartaSans_600SemiBold,
  PlusJakartaSans_700Bold,
} from '@expo-google-fonts/plus-jakarta-sans';
import { SessionProvider, useSession } from '@/src/lib/session';
import { configureGoogle } from '@/src/lib/google';
import { onNotificationTap, registerForPush } from '@/src/lib/push';
import { declineCall } from '@/src/lib/calls';
import { IncomingCallBanner } from '@/src/components/IncomingCallBanner';
import { colors } from '@/src/lib/theme';

configureGoogle();

export default function RootLayout() {
  const [fontsLoaded] = useFonts({
    PlusJakartaSans_400Regular,
    PlusJakartaSans_500Medium,
    PlusJakartaSans_600SemiBold,
    PlusJakartaSans_700Bold,
  });
  if (!fontsLoaded) return <Splash />;
  return (
    <SessionProvider>
      <StatusBar style="dark" />
      <Gate />
    </SessionProvider>
  );
}

function Splash() {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface }}>
      <ActivityIndicator color={colors.orange} />
    </View>
  );
}

// Route guard:
// - no session              -> welcome (guests jump straight to onboarding)
// - session, no profile yet   -> onboarding (name, username, gender, age)
// - session with profile      -> the app
function Gate() {
  const { ready, session, profile } = useSession();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (!ready) return;
    const top = segments[0] as string | undefined;

    if (!session) {
      if (top !== 'welcome' && top !== 'onboarding') router.replace('/welcome');
      return;
    }
    if (!profile) {
      if (top !== 'onboarding') router.replace('/onboarding');
      return;
    }
    if (top === undefined || top === 'welcome' || top === 'onboarding') router.replace('/(tabs)/chats');
  }, [ready, session, profile, segments]);

  useEffect(() => {
    if (profile) registerForPush(profile.id).catch(() => {});
  }, [profile?.id]);

  // Tapping a notification opens the chat or the incoming call.
  useEffect(() => onNotificationTap((data, action) => {
    if (data.type === 'call' && action === 'decline' && data.conversationId) {
      declineCall(data.conversationId, data.logId || null).catch(() => {});
      return;
    }
    if (data.type === 'call' && data.conversationId) {
      router.push({
        pathname: '/call/[id]',
        params: { id: data.conversationId, role: 'callee', kind: data.kind === 'video' ? 'video' : 'audio', peerId: data.fromId ?? '', peerName: data.fromName ?? '', logId: data.logId ?? '' },
      });
    } else if (data.type === 'message' && data.conversationId) {
      router.push({ pathname: '/chat/[id]', params: { id: data.conversationId } });
    }
  }), []);

  if (!ready) return <Splash />;

  return (
    <>
      <Stack screenOptions={{ headerShown: false, contentStyle: { backgroundColor: colors.bg } }}>
        <Stack.Screen name="welcome" options={{ animation: 'fade' }} />
        <Stack.Screen name="onboarding" options={{ gestureEnabled: false }} />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="chat/[id]" options={{ animation: 'slide_from_right' }} />
        <Stack.Screen name="call/[id]" options={{ presentation: 'fullScreenModal', gestureEnabled: false }} />
      </Stack>
      <IncomingCallBanner />
    </>
  );
}
