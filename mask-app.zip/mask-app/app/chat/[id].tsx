import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, KeyboardAvoidingView, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack, useFocusEffect, useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Clipboard from 'expo-clipboard';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { Avatar } from '@/src/components/Avatar';
import { MessagesSkeleton } from '@/src/components/Skeleton';
import { ImageViewer } from '@/src/components/ImageViewer';
import { MessageBubble, QUICK_REACTIONS, type UiMessage } from '@/src/components/MessageBubble';
import {
  deleteMessage, deleteMessageForMe, fetchMessages, getAllChatPrefs, markConversationRead, newId,
  searchInChat, sendMessage, toggleReaction, updateChatPref, type Message,
} from '@/src/lib/api';
import { cancelVoiceNote, pickImage, prepareImage, startVoiceNote, stopVoiceNote, uploadChatImage, uploadVoiceNote } from '@/src/lib/media';
import { useSession } from '@/src/lib/session';
import { supabase } from '@/src/lib/supabase';
import { colors, font, radius } from '@/src/lib/theme';

type Peer = { id: string; username: string; display_name: string; avatar_path: string | null };
type Row = { kind: 'day'; key: string; label: string } | { kind: 'msg'; key: string; msg: UiMessage; showTail: boolean };

function dayLabel(iso: string) {
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (d.toDateString() === today.toDateString()) return 'Today';
  if (d.toDateString() === yesterday.toDateString()) return 'Yesterday';
  return d.toLocaleDateString([], { weekday: 'short', day: 'numeric', month: 'short' });
}

function previewOf(m: { kind: string; body: string | null }) {
  if (m.kind === 'image') return '📷 Photo';
  if (m.kind === 'voice') return '🎤 Voice note';
  return m.body ?? '';
}

function buildRows(messages: UiMessage[]): Row[] {
  const rows: Row[] = [];
  messages.forEach((msg, i) => {
    const prev = messages[i - 1];
    const newDay = !prev || new Date(prev.created_at).toDateString() !== new Date(msg.created_at).toDateString();
    if (newDay) rows.push({ kind: 'day', key: `day-${msg.id}`, label: dayLabel(msg.created_at) });
    const next = messages[i + 1];
    rows.push({ kind: 'msg', key: msg.id, msg, showTail: !next || next.sender_id !== msg.sender_id });
  });
  return rows;
}

export default function ChatScreen() {
  const { id: convId, peerId: peerParam, peerName, kind } = useLocalSearchParams<{ id: string; peerId?: string; peerName?: string; kind?: string }>();
  const isGroup = kind === 'group';
  const router = useRouter();
  const { profile, onlineIds } = useSession();
  const me = profile?.id ?? '';
  const listRef = useRef<FlatList<Row>>(null);

  const [peer, setPeer] = useState<Peer | null>(null);
  const [memberNames, setMemberNames] = useState<Record<string, string>>({});
  const [messages, setMessages] = useState<UiMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [recording, setRecording] = useState(false);
  const [peerTyping, setPeerTyping] = useState(false);
  const [viewerPath, setViewerPath] = useState<string | null>(null);
  const [sheetMsg, setSheetMsg] = useState<UiMessage | null>(null);
  const [replyTo, setReplyTo] = useState<UiMessage | null>(null);
  const [pinnedId, setPinnedId] = useState<string | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Message[]>([]);

  const chRef = useRef<RealtimeChannel | null>(null);
  const typingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastTypingSent = useRef(0);

  const loadPeer = useCallback(async () => {
    if (isGroup) {
      const { data: rows } = await supabase.from('conversation_members').select('profiles(id, display_name)').eq('conversation_id', convId);
      const names: Record<string, string> = {};
      (rows ?? []).forEach((r) => {
        const p = r.profiles as unknown as { id: string; display_name: string } | null;
        if (p) names[p.id] = p.display_name;
      });
      setMemberNames(names);
      setPeer(null);
      return;
    }
    const { data } = await supabase
      .from('conversation_members')
      .select('profiles(id, username, display_name, avatar_path)')
      .eq('conversation_id', convId)
      .neq('user_id', me)
      .maybeSingle();
    setPeer((data?.profiles as unknown as Peer) ?? null);
  }, [convId, me]);

  const loadPrefs = useCallback(async () => {
    if (!me) return;
    try {
      const prefs = await getAllChatPrefs(me);
      setPinnedId(prefs[convId]?.pinned_message_id ?? null);
    } catch {}
  }, [convId, me]);

  const reload = useCallback(async () => {
    try {
      setError(null);
      setMessages(await fetchMessages(convId));
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [convId]);

  useFocusEffect(useCallback(() => { markConversationRead(convId).catch(() => {}); }, [convId]));

  useEffect(() => {
    if (!convId || !me) return;
    loadPeer();
    loadPrefs();
    reload();
    const ch = supabase.channel(`conv:${convId}`, { config: { private: true, broadcast: { self: false } } });
    chRef.current = ch;
    ch.on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` }, async () => {
      await reload();
      markConversationRead(convId).catch(() => {});
    })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'message_reactions' }, () => reload())
      .on('broadcast', { event: 'typing' }, ({ payload }) => {
        if (payload?.userId === me) return;
        setPeerTyping(true);
        if (typingTimer.current) clearTimeout(typingTimer.current);
        typingTimer.current = setTimeout(() => setPeerTyping(false), 3000);
      })
      .subscribe();
    return () => {
      chRef.current = null;
      if (typingTimer.current) clearTimeout(typingTimer.current);
      supabase.removeChannel(ch);
    };
  }, [convId, me, loadPeer, loadPrefs, reload]);

  useEffect(() => () => { cancelVoiceNote(); }, []);

  // Server-side search, debounced.
  useEffect(() => {
    if (!searchOpen) return;
    const t = setTimeout(() => {
      searchInChat(convId, query).then(setSearchResults).catch(() => setSearchResults([]));
    }, 300);
    return () => clearTimeout(t);
  }, [query, searchOpen, convId]);

  const rows = useMemo(() => buildRows(messages), [messages]);
  const byId = useMemo(() => new Map(messages.map((m) => [m.id, m])), [messages]);
  const pinned = pinnedId ? byId.get(pinnedId) ?? null : null;

  const onChangeText = (t: string) => {
    setText(t);
    const now = Date.now();
    if (now - lastTypingSent.current > 2500) {
      lastTypingSent.current = now;
      chRef.current?.send({ type: 'broadcast', event: 'typing', payload: { userId: me } });
    }
  };

  const sendText = async () => {
    const body = text.trim();
    if (!body || !me) return;
    const clientId = newId();
    const replyId = replyTo?.id ?? null;
    setText('');
    setReplyTo(null);
    setMessages((m) => [
      ...m,
      {
        id: clientId, client_id: clientId, conversation_id: convId, sender_id: me, kind: 'text', body,
        media_path: null, media_duration_ms: null, created_at: new Date().toISOString(), delivered_at: null,
        read_at: null, reply_to_id: replyId, forwarded: false, message_reactions: [], pending: true,
      },
    ]);
    try {
      await sendMessage({ clientId, conversationId: convId, senderId: me, kind: 'text', body, replyToId: replyId });
      await reload();
    } catch {
      setMessages((m) => m.map((x) => (x.id === clientId ? { ...x, pending: false, failed: true } : x)));
    }
  };

  const onPickImage = async () => {
    try {
      const picked = await pickImage();
      if (!picked) return;
      setBusy(true);
      const uri = await prepareImage(picked.uri, picked.width, picked.height);
      const path = await uploadChatImage(convId, uri);
      await sendMessage({ conversationId: convId, senderId: me, kind: 'image', mediaPath: path, replyToId: replyTo?.id ?? null });
      setReplyTo(null);
      await reload();
    } catch (e) {
      Alert.alert('Image not sent', (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const onVoiceToggle = async () => {
    if (!recording) {
      try {
        await startVoiceNote();
        setRecording(true);
      } catch (e) {
        Alert.alert('Voice note', (e as Error).message);
      }
      return;
    }
    setRecording(false);
    setBusy(true);
    try {
      const res = await stopVoiceNote();
      if (!res || res.durationMs < 500) return;
      const path = await uploadVoiceNote(convId, res.uri);
      await sendMessage({ conversationId: convId, senderId: me, kind: 'voice', mediaPath: path, durationMs: res.durationMs, replyToId: replyTo?.id ?? null });
      setReplyTo(null);
      await reload();
    } catch (e) {
      Alert.alert('Voice note not sent', (e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const myReactionOf = (m: UiMessage) => m.message_reactions.find((r) => r.user_id === me)?.emoji ?? null;

  const react = async (m: UiMessage, emoji: string) => {
    setSheetMsg(null);
    try {
      await toggleReaction(m.id, me, emoji, myReactionOf(m));
      await reload();
    } catch (e) {
      Alert.alert('Reaction not saved', (e as Error).message);
    }
  };

  const togglePin = async (m: UiMessage) => {
    setSheetMsg(null);
    const next = pinnedId === m.id ? null : m.id;
    try {
      await updateChatPref(me, convId, { pinned_message_id: next });
      setPinnedId(next);
    } catch (e) {
      Alert.alert('Could not pin', (e as Error).message);
    }
  };

  const confirmDelete = (m: UiMessage, forEveryone: boolean) => {
    setSheetMsg(null);
    Alert.alert(
      forEveryone ? 'Delete for everyone?' : 'Delete for me?',
      forEveryone ? 'It will be removed for both of you.' : 'It stays visible to the other person.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              if (forEveryone) await deleteMessage(m.id);
              else await deleteMessageForMe(m.id, me);
              await reload();
            } catch (e) {
              Alert.alert('Could not delete', (e as Error).message);
            }
          },
        },
      ],
    );
  };

  const startCall = (kind: 'audio' | 'video') => {
    if (isGroup) return; // group calls are not built yet
    const id = peer?.id ?? peerParam;
    if (!id) return;
    router.push({ pathname: '/call/[id]', params: { id: convId, role: 'caller', kind, peerId: id, peerName: peer?.display_name ?? peerName ?? '' } });
  };

  const title = peer?.display_name ?? peerName ?? 'Chat';
  const online = peer ? onlineIds.has(peer.id) : false;
  const status = isGroup ? `${Object.keys(memberNames).length} members` : peerTyping ? 'typing…' : online ? 'online' : 'offline';
  const sheetMine = sheetMsg ? sheetMsg.sender_id === me : false;
  const listData = searchOpen ? null : rows;

  const renderBubble = (msg: UiMessage, showTail: boolean) => {
    const mine = msg.sender_id === me;
    const counts = new Map<string, number>();
    msg.message_reactions.forEach((r) => counts.set(r.emoji, (counts.get(r.emoji) ?? 0) + 1));
    const summary = [...counts.entries()].map(([emoji, count]) => ({ emoji, count }));
    const quoted = msg.reply_to_id ? byId.get(msg.reply_to_id) : undefined;
    return (
      <View>
        {isGroup && !mine && <Text style={styles.senderName}>{memberNames[msg.sender_id] ?? 'Member'}</Text>}
        {msg.forwarded && <Text style={[styles.forwardedTag, mine ? { alignSelf: 'flex-end', marginRight: 14 } : { marginLeft: 14 }]}>↪ Forwarded</Text>}
        {msg.reply_to_id && (
          <View style={[styles.quote, mine ? styles.quoteMine : styles.quoteTheirs]}>
            <Text style={styles.quoteName} numberOfLines={1}>{quoted ? (quoted.sender_id === me ? 'You' : peer?.display_name ?? 'Reply') : 'Message'}</Text>
            <Text style={styles.quoteText} numberOfLines={1}>{quoted ? previewOf(quoted) : 'Original message deleted'}</Text>
          </View>
        )}
        <MessageBubble
          msg={msg}
          mine={mine}
          showTail={showTail}
          reactionSummary={summary}
          onLongPress={() => setSheetMsg(msg)}
          onPress={() => { if (msg.kind === 'image' && msg.media_path) setViewerPath(msg.media_path); }}
        />
      </View>
    );
  };

  return (
    <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <Stack.Screen options={{ headerShown: false }} />

      <View style={styles.header}>
        <Pressable onPress={() => router.back()} hitSlop={12} style={styles.iconBtn}>
          <Ionicons name="chevron-back" size={26} color={colors.ink} />
        </Pressable>
        {peer ? (
          <Pressable onPress={() => router.push({ pathname: '/profile/[id]', params: { id: peer.id } })} hitSlop={6}>
            <Avatar name={peer.display_name} path={peer.avatar_path} size={40} />
          </Pressable>
        ) : (
          <View style={{ width: 40 }} />
        )}
        <View style={{ flex: 1 }}>
          {isGroup ? (
            <Pressable onPress={() => router.push({ pathname: '/group/[id]', params: { id: convId } })}>
              <Text style={styles.headerName} numberOfLines={1}>{title}</Text>
            </Pressable>
          ) : (
            <Text style={styles.headerName} numberOfLines={1}>{title}</Text>
          )}
          <View style={styles.statusRow}>
            {online && !peerTyping && <View style={styles.onlineDot} />}
            <Text style={[styles.headerStatus, (peerTyping || online) && { color: colors.blue }]}>{status}</Text>
          </View>
        </View>
        <Pressable onPress={() => { setSearchOpen((s) => !s); setQuery(''); }} hitSlop={8} style={styles.callBtn}>
          <Ionicons name="search" size={18} color={colors.blue} />
        </Pressable>
        <Pressable onPress={() => startCall('audio')} hitSlop={10} style={styles.callBtn} disabled={!peer}>
          <Ionicons name="call" size={18} color={peer ? colors.blue : colors.faint} />
        </Pressable>
        <Pressable onPress={() => startCall('video')} hitSlop={10} style={styles.callBtn} disabled={!peer}>
          <Ionicons name="videocam" size={20} color={peer ? colors.blue : colors.faint} />
        </Pressable>
      </View>

      {searchOpen && (
        <View style={styles.searchBar}>
          <Ionicons name="search" size={16} color={colors.muted} />
          <TextInput value={query} onChangeText={setQuery} placeholder="Search in this chat" placeholderTextColor={colors.faint} style={styles.searchInput} autoFocus />
        </View>
      )}

      {pinned && !searchOpen && (
        <Pressable onLongPress={() => togglePin(pinned)} style={styles.pinBanner}>
          <Ionicons name="pin" size={14} color={colors.orange} />
          <Text style={styles.pinText} numberOfLines={1}>{previewOf(pinned)}</Text>
          <Text style={styles.pinHint}>Long press to unpin</Text>
        </Pressable>
      )}

      {searchOpen ? (
        <FlatList
          data={searchResults}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ padding: 16 }}
          ListEmptyComponent={<Text style={styles.emptySub}>{query.trim().length < 2 ? 'Type at least 2 characters.' : 'No messages found.'}</Text>}
          renderItem={({ item }) => (
            <View style={styles.searchRow}>
              <Text style={styles.searchTime}>{new Date(item.created_at).toLocaleString([], { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</Text>
              <Text style={styles.searchBody} numberOfLines={2}>{previewOf(item)}</Text>
            </View>
          )}
        />
      ) : loading ? (
        <MessagesSkeleton />
      ) : error && messages.length === 0 ? (
        <View style={styles.center}>
          <Text style={styles.errorText}>Could not load messages. {error}</Text>
          <Pressable onPress={reload} style={styles.retry}><Text style={styles.retryText}>Try again</Text></Pressable>
        </View>
      ) : messages.length === 0 ? (
        <View style={styles.center}>
          <View style={styles.emptyIcon}><Ionicons name="hand-left-outline" size={30} color={colors.orange} /></View>
          <Text style={styles.emptyTitle}>Say hi{peer ? ` to @${peer.username}` : ''}</Text>
          <Text style={styles.emptySub}>Messages here are private to the two of you.</Text>
        </View>
      ) : (
        <FlatList
          ref={listRef}
          data={listData ?? []}
          keyExtractor={(r) => r.key}
          contentContainerStyle={{ paddingVertical: 12 }}
          keyboardShouldPersistTaps="handled"
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
          renderItem={({ item }) => {
            if (item.kind === 'day') return <View style={styles.dayWrap}><Text style={styles.dayChip}>{item.label}</Text></View>;
            return renderBubble(item.msg, item.showTail);
          }}
        />
      )}

      {replyTo && (
        <View style={styles.replyBar}>
          <View style={styles.replyAccent} />
          <View style={{ flex: 1 }}>
            <Text style={styles.quoteName}>Replying to {replyTo.sender_id === me ? 'yourself' : peer?.display_name ?? 'them'}</Text>
            <Text style={styles.quoteText} numberOfLines={1}>{previewOf(replyTo)}</Text>
          </View>
          <Pressable onPress={() => setReplyTo(null)} hitSlop={10}><Ionicons name="close" size={20} color={colors.muted} /></Pressable>
        </View>
      )}

      <View style={styles.composerWrap}>
        {recording ? (
          <Pressable onPress={onVoiceToggle} style={styles.recording}>
            <View style={styles.recDot} />
            <Text style={styles.recText}>Recording… tap to send</Text>
          </Pressable>
        ) : (
          <View style={styles.composer}>
            <Pressable onPress={onPickImage} disabled={busy} hitSlop={8} style={styles.iconBtn}>
              <Ionicons name="image-outline" size={24} color={busy ? colors.faint : colors.muted} />
            </Pressable>
            <TextInput value={text} onChangeText={onChangeText} placeholder="Message" placeholderTextColor={colors.faint} multiline style={styles.input} />
            {text.trim().length > 0 ? (
              <Pressable onPress={sendText} style={styles.sendBtn}><Ionicons name="arrow-up" size={20} color="#fff" /></Pressable>
            ) : (
              <Pressable onPress={onVoiceToggle} disabled={busy} style={[styles.sendBtn, { backgroundColor: colors.yellow }]}>
                {busy ? <ActivityIndicator color={colors.ink} /> : <Ionicons name="mic" size={20} color={colors.ink} />}
              </Pressable>
            )}
          </View>
        )}
      </View>

      {viewerPath && <ImageViewer path={viewerPath} onClose={() => setViewerPath(null)} />}

      {/* Message actions: reactions plus reply, forward, copy, pin and delete. */}
      <Modal visible={!!sheetMsg} transparent animationType="fade" onRequestClose={() => setSheetMsg(null)}>
        <Pressable style={styles.sheetBackdrop} onPress={() => setSheetMsg(null)}>
          <Pressable style={styles.sheet} onPress={() => {}}>
            {sheetMsg && (
              <>
                <View style={styles.emojiRow}>
                  {QUICK_REACTIONS.map((emoji) => (
                    <Pressable key={emoji} onPress={() => react(sheetMsg, emoji)} style={[styles.emojiBtn, myReactionOf(sheetMsg) === emoji && styles.emojiOn]}>
                      <Text style={styles.emoji}>{emoji}</Text>
                    </Pressable>
                  ))}
                </View>
                <SheetItem icon="arrow-undo-outline" label="Reply" onPress={() => { setReplyTo(sheetMsg); setSheetMsg(null); }} />
                <SheetItem icon="arrow-redo-outline" label="Forward" onPress={() => { const m = sheetMsg; setSheetMsg(null); router.push({ pathname: '/forward/[id]', params: { id: m.id } }); }} />
                {sheetMsg.kind === 'text' && <SheetItem icon="copy-outline" label="Copy" onPress={() => { Clipboard.setStringAsync(sheetMsg.body ?? ''); setSheetMsg(null); }} />}
                <SheetItem icon={pinnedId === sheetMsg.id ? 'pin-outline' : 'pin'} label={pinnedId === sheetMsg.id ? 'Unpin' : 'Pin'} onPress={() => togglePin(sheetMsg)} />
                <SheetItem icon="trash-outline" label="Delete for me" danger onPress={() => confirmDelete(sheetMsg, false)} />
                {sheetMine && <SheetItem icon="trash" label="Delete for everyone" danger onPress={() => confirmDelete(sheetMsg, true)} />}
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </KeyboardAvoidingView>
  );
}

function SheetItem({ icon, label, onPress, danger }: { icon: keyof typeof Ionicons.glyphMap; label: string; onPress: () => void; danger?: boolean }) {
  return (
    <Pressable onPress={onPress} style={styles.sheetItem}>
      <Ionicons name={icon} size={20} color={danger ? colors.danger : colors.ink} />
      <Text style={[styles.sheetLabel, danger && { color: colors.danger }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.bg },
  header: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingTop: 56, paddingBottom: 12, paddingHorizontal: 12, backgroundColor: colors.surface, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.line },
  iconBtn: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  callBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: colors.blueSoft, alignItems: 'center', justifyContent: 'center' },
  headerName: { fontFamily: font.semibold, fontSize: 16, color: colors.ink },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 1 },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: colors.blue },
  headerStatus: { fontFamily: font.regular, fontSize: 12, color: colors.muted },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  errorText: { fontFamily: font.medium, color: colors.danger, textAlign: 'center' },
  retry: { marginTop: 14, paddingHorizontal: 18, paddingVertical: 10, borderRadius: radius.pill, backgroundColor: colors.blue },
  retryText: { fontFamily: font.semibold, color: '#fff' },
  emptyIcon: { width: 72, height: 72, borderRadius: 36, backgroundColor: colors.orangeSoft, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontFamily: font.bold, fontSize: 18, color: colors.ink, marginTop: 16 },
  emptySub: { fontFamily: font.regular, fontSize: 13, color: colors.muted, marginTop: 6, textAlign: 'center', lineHeight: 19 },
  dayWrap: { alignItems: 'center', marginVertical: 12 },
  dayChip: { fontFamily: font.medium, fontSize: 12, color: colors.muted, backgroundColor: colors.surface, paddingHorizontal: 12, paddingVertical: 4, borderRadius: radius.pill, overflow: 'hidden' },
  senderName: { fontFamily: font.semibold, fontSize: 12, color: colors.blue, marginLeft: 14, marginBottom: 2 },
  forwardedTag: { fontFamily: font.medium, fontSize: 11, color: colors.muted, marginBottom: 2 },
  quote: { marginHorizontal: 12, marginBottom: 2, paddingHorizontal: 10, paddingVertical: 6, borderLeftWidth: 3, borderRadius: radius.sm, maxWidth: '78%' },
  quoteMine: { alignSelf: 'flex-end', backgroundColor: colors.orangeSoft, borderLeftColor: colors.orange },
  quoteTheirs: { alignSelf: 'flex-start', backgroundColor: colors.blueSoft, borderLeftColor: colors.blue },
  quoteName: { fontFamily: font.semibold, fontSize: 12, color: colors.ink },
  quoteText: { fontFamily: font.regular, fontSize: 12, color: colors.muted, marginTop: 1 },
  replyBar: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingHorizontal: 14, paddingVertical: 8, backgroundColor: colors.surface, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.line },
  replyAccent: { width: 3, alignSelf: 'stretch', borderRadius: 2, backgroundColor: colors.orange },
  searchBar: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 12, marginTop: 8, paddingHorizontal: 12, height: 40, borderRadius: radius.pill, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.line },
  searchInput: { flex: 1, fontFamily: font.regular, fontSize: 15, color: colors.ink },
  searchRow: { paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: colors.line },
  searchTime: { fontFamily: font.regular, fontSize: 11, color: colors.faint },
  searchBody: { fontFamily: font.regular, fontSize: 15, color: colors.ink, marginTop: 2 },
  pinBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, marginHorizontal: 12, marginTop: 8, paddingHorizontal: 12, paddingVertical: 8, borderRadius: radius.md, backgroundColor: colors.yellowSoft },
  pinText: { flex: 1, fontFamily: font.medium, fontSize: 13, color: colors.ink },
  pinHint: { fontFamily: font.regular, fontSize: 10, color: colors.muted },
  composerWrap: { backgroundColor: colors.surface, paddingHorizontal: 12, paddingTop: 8, paddingBottom: Platform.OS === 'ios' ? 28 : 12, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: colors.line },
  composer: { flexDirection: 'row', alignItems: 'flex-end', gap: 8 },
  input: { flex: 1, minHeight: 44, maxHeight: 120, borderRadius: 22, paddingHorizontal: 16, paddingTop: 11, paddingBottom: 11, backgroundColor: colors.bg, borderWidth: 1, borderColor: colors.line, fontFamily: font.regular, fontSize: 16, color: colors.ink },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: colors.orange, alignItems: 'center', justifyContent: 'center' },
  recording: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, height: 48, borderRadius: 24, backgroundColor: colors.orangeSoft },
  recDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: colors.danger },
  recText: { fontFamily: font.semibold, color: colors.ink, fontSize: 15 },
  sheetBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: colors.surface, borderTopLeftRadius: radius.lg, borderTopRightRadius: radius.lg, paddingTop: 14, paddingBottom: 32, paddingHorizontal: 12 },
  emojiRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 8 },
  emojiBtn: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  emojiOn: { backgroundColor: colors.yellowSoft },
  emoji: { fontSize: 24 },
  sheetItem: { flexDirection: 'row', alignItems: 'center', gap: 14, paddingVertical: 14, paddingHorizontal: 8 },
  sheetLabel: { fontFamily: font.medium, fontSize: 16, color: colors.ink },
});
