import { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { RTCView, type MediaStream } from 'react-native-webrtc';
import { Ionicons } from '@expo/vector-icons';
import { Avatar } from '@/src/components/Avatar';
import { createCall, type CallController, type CallKind } from '@/src/lib/calls';
import { startRingback, stopTone } from '@/src/lib/sounds';
import { useSession } from '@/src/lib/session';
import { colors, font } from '@/src/lib/theme';

function clock(ms: number) {
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(s).padStart(2, '0');
  return h > 0 ? `${h}:${mm}:${ss}` : `${m}:${ss}`;
}

export default function CallScreen() {
  const { id, role, kind, peerId, peerName, logId } = useLocalSearchParams<{
    id: string; role: 'caller' | 'callee'; kind: CallKind; peerId: string; peerName: string; logId?: string;
  }>();
  const router = useRouter();
  const { profile } = useSession();
  const callKind: CallKind = kind === 'video' ? 'video' : 'audio';

  const [status, setStatus] = useState('Calling…');
  const [connectedAt, setConnectedAt] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const [local, setLocal] = useState<MediaStream | null>(null);
  const [remote, setRemote] = useState<MediaStream | null>(null);
  const [muted, setMuted] = useState(false);
  const [videoOn, setVideoOn] = useState(true);
  const [speaker, setSpeaker] = useState(callKind === 'video');

  const ctrl = useRef<CallController | null>(null);
  const finished = useRef(false);

  // Live call timer
  useEffect(() => {
    if (connectedAt === null) return;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [connectedAt]);

  useEffect(() => {
    if (!profile || !id || !peerId) return;
    const c = createCall({
      conversationId: id,
      meId: profile.id,
      meName: profile.display_name,
      peerId,
      kind: callKind,
      logId: logId || undefined,
      events: {
        onStatus: (s, note) => {
          if (s === 'ringing') startRingback().catch(() => {});
          else stopTone();
          if (s === 'ringing') setStatus('Ringing…');
          else if (s === 'connecting') setStatus('Connecting…');
          else if (s === 'connected') {
            setStatus('Connected');
            setConnectedAt((t) => t ?? Date.now());
          } else {
            // ended, failed, rejected, or missed. Show the reason and close.
            finished.current = true;
            setStatus(note ?? 'Call ended');
            setTimeout(() => router.back(), 2500);
          }
        },
        onLocalStream: setLocal,
        onRemoteStream: setRemote,
      },
    });
    ctrl.current = c;
    const begin = role === 'callee' ? c.accept() : c.start();
    begin.catch((e: Error) => {
      finished.current = true;
      setStatus(e.message || 'Could not start the call');
      setTimeout(() => router.back(), 2000);
    });
    return () => {
      stopTone();
      if (!finished.current) c.hangup();
      ctrl.current = null;
    };
  }, [id, peerId, role, callKind, profile?.id]);

  const hangup = () => {
    finished.current = true;
    ctrl.current?.hangup();
    router.back();
  };

  const elapsed = connectedAt ? clock(now - connectedAt) : null;
  const showVideo = callKind === 'video' && remote;

  return (
    <View style={styles.screen}>
      <Stack.Screen options={{ headerShown: false }} />

      {showVideo ? (
        <RTCView streamURL={remote!.toURL()} style={StyleSheet.absoluteFill} objectFit="cover" />
      ) : (
        <View style={styles.audioCenter}>
          <Avatar name={peerName ?? '?'} size={120} />
          <Text style={styles.name}>{peerName}</Text>
        </View>
      )}

      {callKind === 'video' && local && videoOn && (
        <View style={styles.pip}>
          <RTCView streamURL={local.toURL()} style={StyleSheet.absoluteFill} objectFit="cover" mirror />
        </View>
      )}

      <View style={styles.top}>
        <Text style={styles.status}>{status}</Text>
        {elapsed && <Text style={styles.timer}>{elapsed}</Text>}
      </View>

      <View style={styles.controls}>
        <Control icon={muted ? 'mic-off' : 'mic'} on={muted} label={muted ? 'Unmute' : 'Mute'} onPress={() => setMuted(ctrl.current?.toggleMute() ?? false)} />
        {callKind === 'video' && (
          <Control icon={videoOn ? 'videocam' : 'videocam-off'} on={!videoOn} label={videoOn ? 'Video' : 'Video off'} onPress={() => setVideoOn(ctrl.current?.toggleVideo() ?? true)} />
        )}
        {callKind === 'video' && <Control icon="camera-reverse-outline" label="Flip" onPress={() => ctrl.current?.switchCamera()} />}
        <Control icon={speaker ? 'volume-high' : 'volume-medium-outline'} on={speaker} label="Speaker" onPress={() => { const next = !speaker; setSpeaker(next); ctrl.current?.setSpeaker(next); }} />
        <Pressable onPress={hangup} style={[styles.btn, styles.end]} accessibilityLabel="End call">
          <Ionicons name="call" size={26} color="#fff" style={{ transform: [{ rotate: '135deg' }] }} />
        </Pressable>
      </View>
    </View>
  );
}

function Control({ icon, on, label, onPress }: { icon: keyof typeof Ionicons.glyphMap; on?: boolean; label: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={styles.controlWrap} accessibilityLabel={label}>
      <View style={[styles.btn, { backgroundColor: on ? colors.yellow : 'rgba(255,255,255,0.16)' }]}>
        <Ionicons name={icon} size={24} color={on ? colors.ink : '#fff'} />
      </View>
      <Text style={styles.controlLabel}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: '#101114', alignItems: 'center', justifyContent: 'center' },
  audioCenter: { alignItems: 'center', gap: 18 },
  name: { fontFamily: font.bold, fontSize: 26, color: '#fff' },
  top: { position: 'absolute', top: 64, alignSelf: 'center', alignItems: 'center', gap: 4 },
  status: { fontFamily: font.medium, fontSize: 15, color: 'rgba(255,255,255,0.85)' },
  timer: { fontFamily: font.semibold, fontSize: 18, color: '#fff' },
  pip: { position: 'absolute', top: 120, right: 16, width: 110, height: 150, borderRadius: 16, overflow: 'hidden', backgroundColor: '#000' },
  controls: { position: 'absolute', bottom: 44, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: 18, paddingHorizontal: 16 },
  controlWrap: { alignItems: 'center', gap: 6, width: 72 },
  controlLabel: { fontFamily: font.regular, fontSize: 11, color: 'rgba(255,255,255,0.85)' },
  btn: { width: 60, height: 60, borderRadius: 30, alignItems: 'center', justifyContent: 'center' },
  end: { backgroundColor: colors.danger, width: 68, height: 68, borderRadius: 34, alignSelf: 'flex-start' },
});
