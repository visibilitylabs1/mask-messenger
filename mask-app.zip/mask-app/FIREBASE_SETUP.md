# Push notifications setup (Android)

Push uses Firebase Cloud Messaging through Expo. Do this once:

1. console.firebase.google.com → create a project ("Mask").
2. Add an Android app with package name `com.example.mask` (use your final package name if you changed it).
3. Download `google-services.json` and place it in the project root (next to app.json).
4. In app.json, under "android", add: `"googleServicesFile": "./google-services.json"`.
5. Project settings → Service accounts → Generate new private key (JSON). Upload it to EAS:
   `npx eas-cli credentials` → Android → preview profile → Google Service Account → upload the FCM V1 key.
6. Build a new APK. Push works only in builds made after steps 3 to 5.

Notes:
- Notifications are sent by the `notify` Edge Function. It only notifies people who share a chat with the sender.
- Messages and calls are sent when you send them from the app. If the sender's app is killed mid-send, that one notification is lost.
