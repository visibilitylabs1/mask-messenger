# Mask 2.1.0: build and test guide

Run this on your own computer, in the `mask-app` folder. The build uses your Expo account (visibility-labs-apps).
Free-plan build minutes reset on 1 November 2026 at 00:00 UTC. Until then, builds fail with a quota error.

## 1. One-time setup (only if not done)

1. Firebase: `google-services.json` is already in this folder and `app.json` points to it.
2. Upload the FCM service account key to EAS:
   `npx eas-cli credentials` → Android → preview → Google Service Account → Manage your Google Service Account Key for Push Notifications (FCM V1) → Upload a new service account key.
3. Rotate the service account key you shared earlier (Firebase Console → Project settings → Service accounts).
4. Cloudflare TURN (optional for Wi-Fi testing, needed for mobile data):
   Cloudflare → Calls → TURN Keys → create. Then in Supabase: Edge Functions → Secrets:
   `CLOUDFLARE_TURN_KEY_ID`, `CLOUDFLARE_TURN_KEY_API_TOKEN`.
5. Google sign-in (optional): set `EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID` in `eas.json` (all three profiles) and enable the Google provider in Supabase. Until then, the Google button shows a message and guest mode works.
6. pg_cron: Supabase → Database → Extensions. Confirm it is enabled.

## 2. Verify the project before building

```
cd mask-app
npm install
npm run typecheck
```
Expected: no errors. If there are errors, copy the first 30 lines and send them to the assistant.

## 3. Build the APK

```
npx eas-cli build --platform android --profile preview
```
When it finishes, the terminal prints an APK link. Save it as `mask-messenger.apk`.

Note: `preview` builds include native modules (WebRTC, incall manager, notifications). Expo Go does not.

## 4. Install and smoke test (phone 1 and phone 2)

Use two Android phones, each with the new APK installed.

| # | Check | Expected |
|---|---|---|
| 1 | Open the app | Welcome screen, no crash |
| 2 | Start as guest, fill in name, username, bio, gender, age, Register | Lands in Chats |
| 3 | Google sign-in (only if set up) | Profile setup, then Chats |
| 4 | Find tab: search the other phone's username, open chat | Chat opens |
| 5 | Send text both ways | Messages appear within about 1 second on both phones |
| 6 | Send image (large and small, portrait and landscape) | Image uploads and displays, tap opens full screen |
| 7 | Hold and record a voice note, send | Voice note plays on the other phone |
| 8 | Long-press a message, Reply | Reply bar, quote shows on the new message |
| 9 | Long-press, Forward to another chat | Forwarded tag appears in the other chat |
| 10 | Long-press, Pin, then Unpin | Pinned banner shows and clears |
| 11 | Search icon in chat | Results list shows matches |
| 12 | Long-press a chat in the list: Mute | Muted icon shows; no notification for that chat |
| 13 | Long-press a chat: Archive | Chat moves to Archived |
| 14 | Delete for me / Delete for everyone | Behaves as labelled on both phones |
| 15 | Tap avatar in chat header | Profile shows photo, name, username, bio |
| 16 | Block a user from their profile, then try to message | Messages are rejected |
| 17 | Report a user | "Report sent" |
| 18 | Calls tab | Empty at first, fills after calls |

## 5. Calls (the most important test)

Run each case with both apps open first, then with the receiving app closed.

| # | Case | Expected |
|---|---|---|
| C1 | Audio call Wi-Fi A→B, accept | Ringtone on B, banner, connects, timer runs |
| C2 | Audio call B→A | Same, reversed |
| C3 | Video call both directions | Both videos show; Video off and Flip work |
| C4 | Reject | Caller sees "Call declined" at once; call log says Declined |
| C5 | Caller cancels while ringing | Callee banner clears; log says Missed |
| C6 | Hang up after connecting | Summary shows "Ended · m:ss"; log has duration |
| C7 | Deny mic permission | Clear error message, no crash |
| C8 | Turn Wi-Fi off during call, on again | Recovers, or shows "Connection lost" within about 10 s |
| C9 | 5 calls back to back | Each call works; no stale state |
| C10 | Mobile data A→B | Works only if TURN secrets are set (see 1.4); otherwise may fail |
| C11 | Receiver app closed | Push arrives (needs FCM set up). Accept opens the call; Decline rejects |
| C12 | Speaker button | Audio routes to speaker |
| C13 | Calls tab: tap a call | Starts a new call to that person |

## 6. Notifications

| # | Check | Expected |
|---|---|---|
| N1 | Message while receiver app is closed | Notification appears |
| N2 | Message to a muted chat | No notification |
| N3 | Message from a blocked user | No notification |
| N4 | Call while receiver app is closed | Call notification with Accept and Decline |
| N5 | Log out, then receive a message on that phone | No notification |

Check the outbox if a notification is missing:
```sql
select id, status, attempts, last_error, updated_at from public.push_outbox order by id desc limit 10;
select user_id, platform, left(token, 40), updated_at from public.push_tokens order by updated_at desc limit 5;
```

## 7. Report back

For each failed row, send: the row number, what you did, what you saw, and a screenshot. Calls failures: also say whether both phones were on Wi-Fi.

## Known limits in this build (not bugs, not yet built)

- Lock-screen full-screen call needs native ConnectionService. The notification works, but the call screen opens only after you tap it.
- Picture-in-picture is not implemented.
- Call waiting is not implemented (a second incoming call is shown as a normal banner).
- Push delivery is checked only at the ticket level (Expo accepted it). Final device receipts are not checked.
- End-to-end encryption is not implemented. Do not describe chats as end-to-end encrypted.
- iOS build is not done.
